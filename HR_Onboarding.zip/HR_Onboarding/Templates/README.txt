Die fünf Vorlagen hier ablegen, mit genau diesen Namen /
put the five templates here, with exactly these names:

   Template Email to Managers Regarding New Hires Part 1_Blank.docx
   Executives NewHires Part 2.docx
   Template_New Employee Notification Interface - Beginning of the Month_Blank.docx
   Registrierung Time2eat.oft
   Registrierung Tisoware (Zeiterfassung) .oft

Andere Namen? Unter [Files] in App\Program\Email_Texts.ini eintragen /
other names? Enter them under [Files] in App\Program\Email_Texts.ini
