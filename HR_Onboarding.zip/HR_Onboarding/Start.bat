@echo off
setlocal
rem No "cd" into this folder: cmd.exe cannot do that on a network path (\\server\share), so use full paths.
title HR Onboarding
if not exist "%~dp0App\Program\Onboarding.exe" goto not_unzipped

echo ==============================================================
echo  HR Onboarding - E-Mails fuer neue Mitarbeiter / emails for new hires
echo ==============================================================
echo  1. Liest die Liste im Ordner "Data" / reads the list in "Data"
echo  2. Zeigt, wer was bekommt / shows who gets what
echo  3. Gesendet wird erst nach JA / nothing is sent before you type YES
"%~dp0App\Program\Onboarding.exe"
if errorlevel 1 goto error
echo.
echo Fertig. / Done.
pause
exit /b 0

:error
echo.
echo FEHLER / ERROR - siehe Meldung oben / see the message above.
pause
exit /b 1

:not_unzipped
echo Bitte zuerst die Zip-Datei entpacken: Rechtsklick auf die Zip-Datei, dann "Alle extrahieren".
echo Danach Start.bat im entpackten Ordner starten.
echo Please unzip first: right-click the zip file, then "Extract All". Then run Start.bat from that folder.
pause
exit /b 1
