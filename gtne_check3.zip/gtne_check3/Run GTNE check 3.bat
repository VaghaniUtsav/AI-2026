@echo off
title GTNE check 3 - please do not touch the PC (about 5 minutes)
rem Throwaway check 2026-11-04: which way of starting Edge can open GTNE on this PC. Writes gtne_check3.txt here.
set PY="%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe"
if not exist %PY% set PY=py -V:3.14
%PY% -B "%~dp0gtne_check3.py"
pause
