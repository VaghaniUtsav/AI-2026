# -*- coding: utf-8 -*-
"""THROWAWAY check 3 (2026-11-04). GTNE opens in j.boden's normal Edge, but the tool's Edge (started
by Playwright) gets ERR_CONNECTION_RESET. This tries Edge in 7 ways, from 'plain Edge, nothing
automated' to 'exactly like the tool', then Google Chrome in 2 (if it is installed), and writes
gtne_check3.txt next to itself.
Start: double-click 'Run GTNE check 3.bat'. Edge windows open and close by themselves for about
5 minutes - please don't touch the PC meanwhile. Nothing is saved except the report (only page
titles and yes/no, no page content).
Test elsewhere: gtne_check3.py <url> <text in the page title>"""

import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import winreg

import win32gui
import win32process
from playwright.sync_api import sync_playwright

URL = sys.argv[1] if len(sys.argv) > 1 else \
    "https://gtne.sec.samsung.net/gtne/approval/anonymous/gerp/gtneApprovalView.do?xref1_hd=460A20260914Y3843052"
WANT = sys.argv[2] if len(sys.argv) > 2 else "Global Travel"  # in the title of the real page, not of an error page
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "gtne_check3.txt")
EDGE = next(p for p in (os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
                        os.path.expandvars(r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe")) if os.path.exists(p))
CHROME = next((p for p in (os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
                           os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
                           os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"))
               if os.path.exists(p)), None)
PORT = 9333
# what Playwright adds that a normal Edge doesn't have (extensions off, automation banner, no background fetches)
AUTOMATION_ARGS = ["--enable-automation", "--disable-extensions", "--disable-component-extensions-with-background-pages",
                   "--disable-background-networking"]
lines = []


def out(text=""):
    print(text, flush=True)
    lines.append(text)


def short(e):
    """The net::ERR_... / timeout part of an error, else its first line."""
    m = re.search(r"net::ERR_[A-Z_]+|Timeout \d+ms exceeded|ERR_[A-Z_]+", str(e))
    return m.group(0) if m else str(e).strip().splitlines()[0][:150]


def page_result(page):
    title = page.title()
    return (WANT.lower() in title.lower()), f"title '{title}'"


def windows_of(pid):
    found = []
    win32gui.EnumWindows(lambda h, _: found.append(win32gui.GetWindowText(h)) if win32gui.IsWindowVisible(h)
                         and win32process.GetWindowThreadProcessId(h)[1] == pid and win32gui.GetWindowText(h) else None, None)
    return found


def stop(proc):
    subprocess.run(["taskkill", "/T", "/F", "/PID", str(proc.pid)], capture_output=True)


# ------------------------------------------------------------------------------ the 7 ways
def a_python():
    """Not a browser: Python itself asks the website (uses the HTTPS_PROXY / no_proxy variables)."""
    with urllib.request.urlopen(urllib.request.Request(URL, headers={"User-Agent": "Mozilla/5.0"}), timeout=30) as r:
        body = r.read(300000).decode("utf-8", "replace")
    m = re.search(r"<title>(.*?)</title>", body, re.S | re.I)
    title = m.group(1).strip() if m else "?"
    return WANT.lower() in body.lower(), f"HTTP {r.status}, title '{title}'"


def b_plain_browser(profile, exe=EDGE):
    """Plain Edge (or Chrome), visible, nothing automated - only its own empty profile (like a new user)."""
    if exe is None:
        raise RuntimeError("SKIPPED - Google Chrome is not installed on this PC")
    proc = subprocess.Popen([exe, f"--user-data-dir={profile}", "--no-first-run", "--no-default-browser-check",
                             "--new-window", URL])
    try:
        end, titles = time.time() + 45, []
        while time.time() < end:
            titles = windows_of(proc.pid)
            hit = [t for t in titles if WANT.lower() in t.lower()]
            if hit:
                return True, f"window '{hit[0]}'"
            time.sleep(1)
        return False, f"after 45 s the window says {titles or '(no window found)'}"
    finally:
        stop(proc)


def c_edge_headless_cli(profile):
    """Edge's own hidden mode, no Playwright: prints the page it got."""
    r = subprocess.run([EDGE, "--headless=new", "--disable-gpu", f"--user-data-dir={profile}", "--no-first-run",
                        "--dump-dom", URL], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=90)
    if WANT.lower() in r.stdout.lower():
        return True, "the page text came back"
    err = re.search(r"ERR_[A-Z_]+", r.stdout + r.stderr)
    return False, err.group(0) if err else f"no page ({len(r.stdout)} characters back)"


def d_edge_debug_port(profile):
    """Plain visible Edge started normally, Playwright only connects to it from outside (debugging port)."""
    proc = subprocess.Popen([EDGE, f"--user-data-dir={profile}", f"--remote-debugging-port={PORT}", "--no-first-run",
                             "--no-default-browser-check", "about:blank"])
    try:
        time.sleep(15)  # company extensions install themselves into the new profile
        with sync_playwright() as p:
            browser = p.chromium.connect_over_cdp(f"http://127.0.0.1:{PORT}", timeout=30000)
            context = browser.contexts[0]
            page = context.pages[0] if context.pages else context.new_page()
            page.goto(URL, wait_until="domcontentloaded", timeout=60000)
            return page_result(page)
    finally:
        stop(proc)


def e_playwright_without_automation(profile, headless):
    """Playwright starts Edge, but without its automation switches, extensions allowed, own profile."""
    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(profile, channel="msedge", headless=headless,
                                                       ignore_default_args=AUTOMATION_ARGS, args=["--no-first-run"],
                                                       viewport={"width": 1280, "height": 900})
        try:
            page = context.pages[0] if context.pages else context.new_page()
            time.sleep(15)  # as in d
            page.goto(URL, wait_until="domcontentloaded", timeout=60000)
            return page_result(page)
        finally:
            context.close()


def g_like_the_tool(channel="msedge"):
    """Exactly like the tool (v2026-11-02d): Playwright, hidden Edge (or Chrome), its default switches."""
    if channel == "chrome" and CHROME is None:
        raise RuntimeError("SKIPPED - Google Chrome is not installed on this PC")
    with sync_playwright() as p:
        browser = p.chromium.launch(channel=channel)
        try:
            page = browser.new_page(viewport={"width": 1280, "height": 900})
            page.goto(URL, wait_until="domcontentloaded", timeout=60000)
            return page_result(page)
        finally:
            browser.close()


WAYS = [
    ("A  Python, no browser", lambda prof: a_python()),
    ("B  plain Edge, visible, new profile, nothing automated", b_plain_browser),
    ("C  Edge's own hidden mode (no Playwright)", c_edge_headless_cli),
    ("D  plain Edge + Playwright connects from outside", d_edge_debug_port),
    ("E  Playwright, VISIBLE, without automation switches", lambda prof: e_playwright_without_automation(prof, False)),
    ("F  Playwright, HIDDEN, without automation switches", lambda prof: e_playwright_without_automation(prof, True)),
    ("G  exactly like the tool (hidden, Playwright defaults)", lambda prof: g_like_the_tool()),
    ("H  plain CHROME, visible, new profile, nothing automated", lambda prof: b_plain_browser(prof, CHROME)),
    ("I  CHROME exactly like the tool (hidden, Playwright)", lambda prof: g_like_the_tool("chrome")),
]


# ------------------------------------------------------------------------------ facts about this PC
def facts():
    app = os.path.dirname(EDGE)
    versions = [d for d in os.listdir(app) if re.fullmatch(r"\d+\.\d+\.\d+\.\d+", d)]
    out(f"Edge: {EDGE}, version(s) {', '.join(versions) or '?'}")
    if CHROME:
        versions = [d for d in os.listdir(os.path.dirname(CHROME)) if re.fullmatch(r"\d+\.\d+\.\d+\.\d+", d)]
        out(f"Chrome: {CHROME}, version(s) {', '.join(versions) or '?'}")
    else:
        out("Chrome: not installed")
    proxies = [f"{k}={v}" for k, v in os.environ.items() if k.lower() in ("http_proxy", "https_proxy", "no_proxy", "all_proxy")]
    out("Proxy variables: " + (", ".join(proxies) or "(none)"))
    interesting = re.compile(r"proxy|extension|cert|auth|url|dns|secure|quic|debug|automation|headless", re.I)
    for hive, name in ((winreg.HKEY_LOCAL_MACHINE, "HKLM"), (winreg.HKEY_CURRENT_USER, "HKCU")):
        try:
            key = winreg.OpenKey(hive, r"SOFTWARE\Policies\Microsoft\Edge")
        except OSError:
            out(f"Edge policies {name}: none")
            continue
        values, subkeys, i = [], [], 0
        while True:
            try:
                values.append(winreg.EnumValue(key, i)[:2])
                i += 1
            except OSError:
                break
        i = 0
        while True:
            try:
                subkeys.append(winreg.EnumKey(key, i))
                i += 1
            except OSError:
                break
        out(f"Edge policies {name}: " + ", ".join(f"{n}={str(v)[:100]}" if interesting.search(n) else n for n, v in values))
        for sub in subkeys:
            k, items, i = winreg.OpenKey(key, sub), [], 0
            while True:
                try:
                    items.append(str(winreg.EnumValue(k, i)[1])[:100])
                    i += 1
                except OSError:
                    break
            out(f"  {name} {sub}: {items}")
    names = subprocess.run(["tasklist", "/fo", "csv", "/nh"], capture_output=True, text=True, errors="replace").stdout
    keywords = ("zscaler", "netskope", "forcepoint", "symantec", "mcafee", "crowdstrike", "csfalcon", "sentinel", "cisco",
                "umbrella", "cyber", "sds", "knox", "samsung", "genian", "ahnlab", "v3", "inca", "npro", "fasoo",
                "softcamp", "markany", "dlp", "proxy", "vpn", "secure", "agent", "guard", "ztna", "pulse", "forti",
                "palo", "globalprotect", "trend", "sophos", "kaspersky", "eset", "tanium", "nac")
    running = sorted({line.split('","')[0].strip('"') for line in names.splitlines() if line})
    out("Security/network programs running: " + (", ".join(n for n in running if any(k in n.lower() for k in keywords))
                                                 or "(none recognised)"))


def main():
    out(f"gtne_check3 2026-11-04 on {os.environ.get('COMPUTERNAME', '?')}, user {os.environ.get('USERNAME', '?')}, "
        f"{time.strftime('%d.%m.%Y %H:%M')}")
    out(f"Address: {URL}")
    out(f"Counts as open when the title has: '{WANT}'")
    try:
        facts()
    except Exception as e:
        out(f"(facts could not be read: {e!r})")
    out()
    for label, way in WAYS:
        profile = tempfile.mkdtemp(prefix="gtne_check3_")
        started = time.time()
        try:
            ok, detail = way(profile)
            result = ("OPENED   " if ok else "NOT OPEN ") + detail
        except Exception as e:
            result = str(e) if str(e).startswith("SKIPPED") else "FAILED   " + short(e)
        out(f"{label:58} {result}  ({time.time() - started:.0f} s)")
        time.sleep(2)
        shutil.rmtree(profile, ignore_errors=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        out(f"STOPPED: {e!r}")
    finally:
        with open(OUT, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        print(f"\nReport: {OUT}\nPlease send this file to Utsav.")
