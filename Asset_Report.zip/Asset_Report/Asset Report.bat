@echo off
setlocal
rem No "cd" into this folder: cmd.exe cannot do that on a network path (\\server\share), so use full paths.
title Asset-Report
if not exist "%~dp0App\Asset_Report.exe" goto not_unzipped

echo ==============================================================
echo  Asset-Report fuer HR / asset report for HR
echo ==============================================================
echo  1. Liest die fuenf Exporte im Ordner Data / reads the five exports in the folder Data:
echo     SAP-Zaehlliste, Inventaris Notebook + Smartphone, MySEG, Externe
echo  2. Gibt jeder Inventarnummer einen Status /
echo     gives every Inventarnummer one status
echo  3. Speichert und oeffnet Reports\Asset Report.xlsx /
echo     saves and opens Reports\Asset Report.xlsx
"%~dp0App\Asset_Report.exe" --data "%~dp0Data" --reports "%~dp0Reports"
if errorlevel 1 goto error
start "" "%~dp0Reports\Asset Report.xlsx"
echo.
echo Fertig. / Done.
pause
exit /b 0

:error
echo.
echo FEHLER / ERROR - siehe Meldung oben / see the message above.
pause
exit /b 1

:not_unzipped
echo Bitte zuerst die Zip-Datei entpacken: Rechtsklick auf die Zip-Datei, dann "Alle extrahieren".
echo Danach Asset Report.bat im entpackten Ordner starten.
echo Please unzip first: right-click the zip file, then "Extract All". Then run Asset Report.bat from that folder.
pause
exit /b 1
