@echo off
setlocal
rem No "cd" into this folder: cmd.exe cannot do that on a network path (\\server\share), so use full paths.
title Asset-Report pro Person
if not exist "%~dp0App\Asset_Per_Person.exe" goto not_unzipped

echo ==============================================================
echo  Asset-Report pro Person / asset report per person
echo ==============================================================
echo  1. Liest die fuenf Exporte im Ordner Data / reads the five exports in the folder Data:
echo     SAP-Zaehlliste, Inventaris Notebook + Smartphone, MySEG, Externe
echo  2. Eine Zeile je Person: ihre Nummern in SAP, Inventaris und Formular /
echo     one line per person: their numbers in SAP, Inventaris and the form
echo  3. Speichert und oeffnet Reports\Asset Per Person.xlsx /
echo     saves and opens Reports\Asset Per Person.xlsx
"%~dp0App\Asset_Per_Person.exe" --data "%~dp0Data" --reports "%~dp0Reports"
if errorlevel 1 goto error
start "" "%~dp0Reports\Asset Per Person.xlsx"
echo.
echo Fertig. / Done.
pause
exit /b 0

:error
echo.
echo FEHLER / ERROR - siehe Meldung oben / see the message above.
pause
exit /b 1

:not_unzipped
echo Bitte zuerst die Zip-Datei entpacken: Rechtsklick auf die Zip-Datei, dann "Alle extrahieren".
echo Danach Asset Per Person.bat im entpackten Ordner starten.
echo Please unzip first: right-click the zip file, then "Extract All". Then run Asset Per Person.bat from that folder.
pause
exit /b 1
