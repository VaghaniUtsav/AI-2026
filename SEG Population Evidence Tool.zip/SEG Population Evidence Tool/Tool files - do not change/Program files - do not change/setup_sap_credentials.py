# -*- coding: utf-8 -*-
"""
setup_sap_credentials.py
=========================
One-time setup of the personal SAP credentials for the SEG tool. Every user runs this
once on their own Windows account ('3 - Save SAP password'), and again when the SAP
password changes - the saved SAP user is offered then, so only the password is typed.

Nothing is stored in plain text (neither in a file nor in the code): the Windows
Credential Manager keeps it encrypted (package 'keyring'). While the password is
typed, a * shows for each character.

Run with:
    python setup_sap_credentials.py
"""

import msvcrt

import keyring

KEYRING_SERVICE = "UploadIDTool_SAP"


def ask_password(prompt):
    """The password from the keyboard, a * for each character - with nothing shown, people
    thought their typing didn't arrive (2026-11-02)."""
    print(prompt, end="", flush=True)
    chars = []
    while (key := msvcrt.getwch()) not in "\r\n":
        if key == "\x03":  # Ctrl+C
            raise KeyboardInterrupt
        if key in "\x00\xe0" and msvcrt.kbhit():  # an arrow or function key sends a second code - skip both
            msvcrt.getwch()
        elif key == "\b":
            if chars:
                chars.pop()
                print("\b \b", end="", flush=True)
        elif key >= " ":  # not Tab, Esc or another control key
            chars.append(key)
            print("*", end="", flush=True)
    print()
    return "".join(chars)


def main():
    print("=" * 60)
    print("Save your SAP user and password for the SEG tool")
    print("=" * 60)
    print("Windows keeps them safe in its Credential Manager - not in a file.\n")

    saved = keyring.get_password(KEYRING_SERVICE, "username")
    user = input(f"SAP username (press Enter for {saved}): " if saved else "SAP username: ").strip() or saved
    if not user:
        print("\nCancelled: no username typed - nothing saved.")
        return
    password = ask_password("SAP password: ")
    if not password:
        print("\nCancelled: no password typed - nothing saved.")
        return
    # twice: a typo would only show as a failed SAP logon, and a few of those lock the SAP user
    if ask_password("The same password again: ") != password:
        print("\nCancelled: the two passwords are not the same - nothing saved. Please start again.")
        return
    try:
        keyring.set_password(KEYRING_SERVICE, "username", user)
        keyring.set_password(KEYRING_SERVICE, user, password)
    except Exception as e:
        print(f"\nNOT SAVED - the Windows Credential Manager reported: {e}")
        return
    print(f"\nSaved for user '{user}'. You can close this window.")
    print("When your SAP password changes, double-click '3 - Save SAP password' again.")


if __name__ == "__main__":
    main()
