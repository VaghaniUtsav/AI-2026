# -*- coding: utf-8 -*-
"""Quick self-check of population_evidence_tool.py - needs no SAP and no template:
    python test_evidences.py"""

import contextlib
import datetime as dt
import filecmp
import glob
import io
import os
import re
import shutil
import tempfile
import time
import types
import zipfile

import pymupdf
import win32com.client as win32

import population_evidence_tool as tool
import sap_connector
import setup_sap_credentials as setup


class FakeAttachmentList:
    """Stands in for the ALV list of the 'File attachment' box (Icon and Title columns)."""
    ColumnCount = 2

    def __init__(self, titles, icons=None):
        self.titles = titles
        self.icons = icons or [""] * len(titles)
        self.RowCount = len(titles)

    def ColumnOrder(self, i):
        return ("IC_AR_TYPE", "TEXT")[i]

    def GetDisplayedColumnTitle(self, column):
        return {"IC_AR_TYPE": "Icon", "TEXT": "Title"}[column]

    def GetCellValue(self, row, column):
        return (self.icons if column == "IC_AR_TYPE" else self.titles)[row]


class NoWindows:
    """An empty SAP collection: no popups, no controls."""
    Count = 0


class FakeSAP:
    """SAP session whose window has this title - every element is the session
    itself, HardCopy saves the picture."""
    Busy = False
    Children = NoWindows()

    def __init__(self, title):
        self.Text = title
        self.ActiveWindow = self

    def findById(self, id):
        return self

    def sendVKey(self, key):
        pass

    def press(self):
        pass

    def pressToolbarButton(self, button):
        pass

    def HardCopy(self, path, image_type):
        open(path, "wb").close()


class FakeDetails(FakeSAP):
    """The 'Details' popup of an attachment: rows of field name | value."""

    def __init__(self, fields):
        super().__init__("Details")
        self.fields = fields
        self.RowCount = len(fields)

    def GetCellValue(self, row, column):
        return self.fields[row][column == "VALUE"]

    def close(self):
        self.closed = True


def make_pdf(path, text=""):
    with pymupdf.open() as pdf:
        page = pdf.new_page()
        if text:
            page.insert_text((72, 72), text)
        pdf.save(path)


LINK = tool.LINK_ICON
box = FakeAttachmentList([  # the real box of document 446941
    "", "", "BQMS Exception for non-marketing invoice", "ANTALIS Rg. 7302506840-Samsung Electronics",
    "Request No :R460AE01040S2603230005", "C460_RECALL_DE90667754.pdf", "MYREQCONTE",
], ["", "", "", "", "", "", LINK])
assert tool._invoice_row(box) == 5  # the C460 file - wins over the link
assert tool._invoice_row(FakeAttachmentList(["C460_a.pdf", "x", "C460_b.pdf", "y"])) == 2  # several: the last one
gtne = FakeAttachmentList(["GTNE EVIDENCE", ""], [LINK, ""])  # the real box of document 1214349 (+ total row)
assert tool._invoice_row(gtne) is None
assert tool._link_row(gtne) == 0
assert tool._link_row(FakeAttachmentList(["MYREQCONTE", "GTNE EVIDENCE", "OTHER LINK"], [LINK] * 3)) == 1
assert tool._link_row(FakeAttachmentList(["A", "x.pdf", "B"], [LINK, "", LINK])) == 2  # no EVIDENCE: the last link
assert tool._link_row(FakeAttachmentList(["ANTALIS Rg. 7302506840"])) is None
assert tool._layout_row(FakeAttachmentList(["/STANDARD", "/EVI", "/EVI2"]), "/EVI") == 1  # the user's FB03 layout
assert tool._layout_row(FakeAttachmentList(["/EVIDENCE", "EVI"]), "/EVI") is None  # only the exact name
assert [r for r, _, _ in tool._attachments(gtne)] == [0]  # the yellow total row (no icon, no title) is no attachment
url = "https://gtne.sec.samsung.net/gtne/approval/anonymous/gerp/gtneApprovalView.do?xref1_hd=460A20260907Y3839798"
details = FakeDetails([("Icon Name", LINK), ("Extension", "HTM"), ("URL Sequential Key", "16534513"), ("URL", url)])
assert tool._details(details, details, 0) == {"Icon Name": LINK, "Extension": "HTM",
                                              "URL Sequential Key": "16534513", "URL": url}
assert details.closed  # the attachment list is in use again afterwards

# Several PDFs: the Assignment and the amount count most, then invoice words; a tie -> the later one
pick = tool._pick_invoice
assert pick(["Contract total", "Rg. 7302506840", "Rechnung"], "7302506840", None) == (1, [1, 11, 1])
assert pick(["Gesamt 1.234,56 EUR", "Total 1,234.56", "1234,56"], "", -1234.56) == (1, [11, 11, 10])
assert pick(["", ""], "4711", 50.0) == (1, [0, 0])  # nothing matches: the last one
assert pick(["150,00 and 50,001 and 47110"], "4711", 50.0)[1] == [0]  # only whole numbers count
assert pick(["the customer must pay in August"], "", None)[1] == [0]  # 'ust' only as a word

assert tool._label_rows(8)[:3] == [21, 64, 107]  # first label in row 21 like the manual sheet, then every 43 rows
assert tool._year_of(dt.datetime(2026, 1, 6)) == 2026
assert tool._year_of("06.01.2026") == 2026
assert tool._year_of("") is None
assert tool._text(446941.0) == "446941" and tool._text(" 0073 ") == "0073"


# Each SAP user may keep their own date format (SU3): the tool reads it from FBL4N's key date, types
# the period that way and reads every SAP format back (2026-10-27)
class FBL4NScreen(FakeSAP):
    def __init__(self, key_date):
        super().__init__("G/L Account Line Item Display")
        self.key_date = types.SimpleNamespace(text=key_date)

    def findById(self, id):
        return self.key_date if id == tool.KEY_DATE_FIELD else self


try:
    for shown, fmt in [("27.10.2026", "%d.%m.%Y"), ("10/27/2026", "%m/%d/%Y"), ("10-27-2026", "%m-%d-%Y"),
                       ("2026.10.27", "%Y.%m.%d"), ("2026/10/27", "%Y/%m/%d"), ("2026-10-27", "%Y-%m-%d")]:
        tool._use_sap_date_format(FBL4NScreen(shown))
        assert tool.SAP_DATE_FORMAT == fmt, (shown, tool.SAP_DATE_FORMAT)
        assert tool._parse_sap_date(shown) == dt.date(2026, 10, 27) and tool._year_of(shown) == 2026
    tool._use_sap_date_format(FBL4NScreen(""))  # nothing to read: the format stays
    assert tool.SAP_DATE_FORMAT == "%Y-%m-%d"
finally:
    tool.SAP_DATE_FORMAT = tool.SAP_DATE_FORMATS[0]

assert tool._parse_amount("1.234,56-") == -1234.56  # German separators, trailing minus
assert tool._parse_amount("1,234.56") == 1234.56 and tool._parse_amount("-500") == -500.0
assert tool._parse_amount("1.234") == 1234.0  # a single dot before 3 digits is a thousands separator
assert tool._parse_amount("1,56-") == -1.56 and tool._parse_amount("") is None

# No K:\ path any more: every folder is found from where the tool lies, so the share can be K:, another
# letter or \\server\share on each PC. Each run fills a new copy of the master template (2026-10-26)
# The tool's folders lie together in 'Tool files - do not change', 'Excel results' next to it (2026-10-28)
tool_files = os.path.dirname(os.path.dirname(os.path.abspath(tool.__file__)))
assert tool.DATA_DIR == os.path.join(tool_files, "ICFR Control Backup and config"), tool.DATA_DIR
assert tool.LOG_DIR == os.path.join(tool_files, "Logs"), tool.LOG_DIR
assert tool.RESULTS_DIR == os.path.join(os.path.dirname(tool_files), "Excel results"), tool.RESULTS_DIR
# A copy of the whole folder works anywhere - but not in a folder too deep for Windows (2026-11-02)
assert tool._path_too_long() is None, tool.TOOL_DIR
real_tool_dir, tool.TOOL_DIR = tool.TOOL_DIR, "C:\\" + "x" * tool.MAX_TOOL_PATH
assert "too long" in tool._path_too_long() and tool.TOOL_DIR in tool._path_too_long()
tool.TOOL_DIR = real_tool_dir
real_dirs = tool.DATA_DIR, tool.RESULTS_DIR
try:
    with tempfile.TemporaryDirectory() as tmp:
        tool.DATA_DIR, tool.RESULTS_DIR = os.path.join(tmp, "data"), os.path.join(tmp, "results")
        os.makedirs(tool.DATA_DIR)
        for find, says in [(tool.find_template, tool.DATA_DIR), (tool.latest_result, "1 - Run Control")]:
            try:
                find()
            except RuntimeError as e:
                assert says in str(e), str(e)
            else:
                raise AssertionError(f"{find.__name__} must stop when there is no file")
        master = os.path.join(tool.DATA_DIR, "GA-02-006_SEG.xlsb")
        with open(master, "wb") as f:
            f.write(b"master")
        assert tool.find_template() == master
        first = tool.new_result_file(master, dt.date(2026, 7, 1), dt.date(2026, 9, 30))
        assert os.path.dirname(first) == tool.RESULTS_DIR and first.endswith(".xlsb"), first
        assert os.path.basename(first).startswith("GA-02-006_SEG_2026-07-01_to_2026-09-30_made_"), first
        assert filecmp.cmp(first, master, shallow=False)
        renamed = os.path.join(tool.RESULTS_DIR, "GA-02-006_SEG Q3 checked.xlsb")  # people may rename it
        open(renamed, "wb").close()
        open(os.path.join(tool.RESULTS_DIR, "~$GA-02-006_SEG Q3 checked.xlsb"), "wb").close()  # Excel's lock file
        os.utime(first, (time.time() + 3600,) * 2)  # the older file saved again later
        assert tool.latest_result() == renamed  # 'Redo pictures only': the newest made, not the last saved
finally:
    tool.DATA_DIR, tool.RESULTS_DIR = real_dirs

# Everyone's runs in one log were hard to tell apart (user, 2026-11-02): one log per run in
# Logs\<Windows user>\, the result in its name, a summary on top, the technical details at the bottom
real_log_dir = tool.LOG_DIR
try:
    with tempfile.TemporaryDirectory() as tmp:
        tool.LOG_DIR = tmp
        run = tool.RunLog("Run Control")
        assert os.path.dirname(run.path) == os.path.join(tmp, os.environ["USERNAME"]), run.path
        assert run.path.endswith("_Run-Control_running.log"), run.path
        tool.LOGGER.info("a step")
        tool.LOGGER.warning("Sample 7 (document 123): no invoice picture - the attachment section is empty")
        run.excel = r"K:\Excel results\GA-02-006_SEG_test.xlsb"
        try:
            raise RuntimeError("SAP did not open FBL4N.\n\nPlease ask the SAP team.")
        except RuntimeError as e:
            stopped = run.finish(e)
        assert stopped.endswith("_Run-Control_STOPPED.log") and not os.path.exists(run.path), stopped
        with open(stopped, encoding="utf-8") as f:
            top, body = f.read().split("STEP BY STEP")
        assert top.startswith("RESULT:   STOPPED"), top
        assert "WHY IT STOPPED\n  SAP did not open FBL4N." in top and "WARNINGS (1)\n  - Sample 7 " in top, top
        assert "EXCEL FILE\n  K:\\Excel results" in top and "Traceback" not in top, top
        assert "a step" in body and "Technical details" in body and "Traceback" in body, body
        assert tool.RunLog("Redo pictures only").finish().endswith("_Redo-pictures-only_OK.log")
finally:
    tool.LOG_DIR = real_log_dir


# An open SAP is reused only in the right system, client and language - a German logon finds none of
# the English screen texts, another system gives the wrong data. Otherwise the tool stops instead of
# closing SAP windows that may have work in them (2026-10-23)
class Collection(list):
    """A SAP GUI collection: .Count and (i)."""
    Count = property(len)
    __call__ = list.__getitem__


def sap_open_with(*connections):
    """A running SAP GUI with these connections: (SAP Logon entry, [(user, client, language) of each session])."""
    def session(user, client, language):
        return types.SimpleNamespace(Info=types.SimpleNamespace(User=user, Client=client, Language=language))
    engine = types.SimpleNamespace(Children=Collection(
        types.SimpleNamespace(Description=entry, Children=Collection(session(*s) for s in sessions))
        for entry, sessions in connections))
    sap_connector.win32 = types.SimpleNamespace(GetObject=lambda name: types.SimpleNamespace(GetScriptingEngine=engine))
    return engine


def sap_not_running(name):
    raise OSError("no SAPGUI object")  # GetObject when SAP is not running


real_win32 = sap_connector.win32
try:
    sap = sap_open_with(("01. SET ERP QAS", [("VAGHANI", "100", "EN")]),
                        ("01. SET ERP PRD", [("", "", ""), ("VAGHANI", "100", "EN")]))
    assert sap_connector._try_get_existing_session() is sap.Children(1).Children(1)  # not the test system
    for entry, client, language in [("01. SET ERP PRD", "100", "DE"), ("01. SET ERP PRD", "200", "EN"),
                                    ("01. SET ERP QAS", "100", "EN")]:  # German, another client, the test system
        sap_open_with((entry, [("VAGHANI", client, language)]))
        try:
            sap_connector._try_get_existing_session()
        except RuntimeError:
            pass  # stops - its message says to close SAP
        else:
            raise AssertionError(f"the SAP session {entry} / {client} / {language} must not be used")
    sap_open_with(("01. SET ERP PRD", [("", "", "")]))  # only the logon screen: the tool logs on by itself
    assert sap_connector._try_get_existing_session() is None
    sap_connector.win32 = types.SimpleNamespace(GetObject=sap_not_running)
    assert sap_connector._try_get_existing_session() is None
finally:
    sap_connector.win32 = real_win32

# SAP Logon is looked for in the 64-bit and the 32-bit folder - another PC may have the older SAP GUI.
# Neither there: a plain message instead of 'WinError 2', and before any SAP window is closed (2026-10-26)
real_paths = sap_connector.SAP_LOGON_PATHS
sap_connector.SAP_LOGON_PATHS = (r"C:\nowhere\saplogon.exe",)
try:
    sap_connector.sap_login()
except RuntimeError as e:
    assert "SAP Logon was not found" in str(e), str(e)
else:
    raise AssertionError("sap_login must stop without SAP Logon")
finally:
    sap_connector.SAP_LOGON_PATHS = real_paths

# On c.liptay's PC Windows refused Python starting taskkill with 'WinError 5' and the tool stopped.
# Closing SAP is skipped then; if SAP Logon can't be started either, a plain message (2026-10-27)
def blocked(*args, **kwargs):
    raise PermissionError(13, "Zugriff verweigert", None, 5)


real_subprocess, real_credentials = sap_connector.subprocess, sap_connector._get_credentials
sap_connector.subprocess = types.SimpleNamespace(run=blocked, Popen=blocked, DEVNULL=None)
sap_connector._get_credentials = lambda: ("USER", "secret")
sap_connector.SAP_LOGON_PATHS = (tool.__file__,)  # any file that exists
try:
    sap_connector._close_existing_sap()  # must not stop the tool
    sap_connector.sap_login()
except RuntimeError as e:
    assert "log on to SAP by hand" in str(e), str(e)
else:
    raise AssertionError("sap_login must stop when SAP Logon can't be started")
finally:
    sap_connector.subprocess, sap_connector._get_credentials = real_subprocess, real_credentials
    sap_connector.SAP_LOGON_PATHS = real_paths


# On c.liptay's SAP user FBL4N didn't show its screen and the tool stopped with only 'The control
# could not be found by id'. Now the message has SAP's window title and status bar (2026-10-27)
class NoFBL4N(FakeSAP):
    def findById(self, id):
        if id.endswith("radX_AISEL"):
            raise Exception("The control could not be found by id.")
        return self

    def maximize(self):
        pass


try:
    tool.run_fbl4n(NoFBL4N("You are not authorized to use transaction FBL4N"),
                   dt.date(2026, 1, 1), dt.date(2026, 3, 31), "unused")
except RuntimeError as e:
    assert "not authorized to use transaction FBL4N" in str(e), str(e)
else:
    raise AssertionError("run_fbl4n must stop with SAP's message when FBL4N doesn't open")


# '3 - Save SAP password': a * for each typed character - with nothing shown, people thought their typing
# didn't arrive. The saved SAP user is offered, so after a password change only the password is typed (2026-11-02)
def typing(keys, waiting=True):
    """Keys as msvcrt.getwch gives them; waiting = kbhit(): a second code is already there."""
    keys = iter(keys)
    setup.msvcrt = types.SimpleNamespace(getwch=lambda: next(keys), kbhit=lambda: waiting)


real_msvcrt, real_keyring = setup.msvcrt, setup.keyring
try:
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        typing("ab\bc\xe0Hd\r")  # Backspace takes one back, an arrow key (2 codes) is ignored
        assert setup.ask_password("SAP password: ") == "acd"
        typing("\xe0\r", waiting=False)  # a typed 'à' is no arrow key
        assert setup.ask_password("") == "\xe0"
    assert out.getvalue() == "SAP password: **\b \b**\n*\n", repr(out.getvalue())
    store = {"username": "C.LIPTAY"}
    setup.keyring = types.SimpleNamespace(get_password=lambda service, key: store.get(key),
                                          set_password=lambda service, key, value: store.__setitem__(key, value))
    prompts = []
    setup.input = lambda prompt: prompts.append(prompt) or ""  # Enter: keep the saved user
    typing("new1\rnew1\r")
    with contextlib.redirect_stdout(io.StringIO()):
        setup.main()
    assert "C.LIPTAY" in prompts[0] and store == {"username": "C.LIPTAY", "C.LIPTAY": "new1"}, (prompts, store)
finally:
    setup.msvcrt, setup.keyring = real_msvcrt, real_keyring
    vars(setup).pop("input", None)

# On the K: share os.path.isfile() says False for files that exist (log of 2026-10-15) -
# neither picture may depend on it
real_isfile, os.path.isfile = os.path.isfile, lambda path: False
real = {name: getattr(tool, name) for name in ("_attachment_list", "_details", "_download")}
try:
    with tempfile.TemporaryDirectory() as tmp:
        stem = os.path.join(tmp, "002_1549")
        sample = tool.Sample(28, 2, "1549", 2026, "460A20260105TV000043")
        fb03 = FakeSAP("Display Document: Data Entry View")
        # this fake screen has no list of line items, so /EVI can't be chosen: a warning, and the picture
        # is still taken (in SAP's standard layout)
        assert tool._capture_document(fb03, sample, stem + "_document") == stem + "_document.png"
        history = FakeSAP("Display Workflow History")
        assert tool._capture_workflow(history, sample, stem + "_workflow") == stem + "_workflow.png"
        assert history.text == "01.01.2025"  # last field typed: created-from, SAP format DD.MM.YYYY, a year early
        with pymupdf.open() as pdf:
            pdf.new_page()
            pdf.save(stem + "_invoice.pdf")
        assert os.path.exists(tool._first_page_as_png(stem + "_invoice.pdf", stem + "_invoice.png"))
        # whole page, not only the visible 900 px: a 3000 px tall page (made here, no network) -
        # kept as it is, and shown in Excel as 2 strips side by side
        tall = "data:text/html,<body style='margin:0'><div style='height:3000px'>GTNE</div></body>"
        picture = pymupdf.Pixmap(tool._website_as_png(tall, stem + "_site.png"))
        page = pymupdf.Pixmap(stem + "_site_page.png")
        assert (page.width, page.height) == (tool.WEBSITE_WIDTH, 3000), (page.width, page.height)
        assert (picture.width, picture.height) == (2 * tool.WEBSITE_WIDTH + tool.STRIP_GAP, 1500), picture.irect

        # Which attachment becomes the invoice picture - the box, its Details and 'Download' are fakes
        sources = [os.path.join(tmp, f"source{i}.pdf") for i in range(3)]  # what 'Download' delivers per row
        tool._download = lambda session, grid, row, stem: shutil.copy(sources[row], stem + ".pdf")
        opened = []  # rows whose Details popup was opened (about 3s each in SAP)

        def invoice_of(titles, icons, extensions, sample=sample):
            grid = FakeAttachmentList(titles + [""], icons + [""])  # + the yellow total row
            tool._attachment_list = lambda session: grid
            tool._details = lambda session, grid, row: opened.append(row) or {"Extension": extensions[row]}
            return tool._capture_invoice(FakeSAP("Display Document: Data Entry View"), sample, stem2 + "_invoice")

        def error_of(*box):
            try:
                invoice_of(*box)
            except RuntimeError as e:
                return str(e)
            raise AssertionError(f"expected no invoice picture for {box}")

        stem2 = os.path.join(tmp, "003_446941")
        assert error_of([], [], []) == "the attachment section is empty"
        assert error_of(["Contract", "ETC"], ["@J2@", "@J3@"], ["XLSX", "DOCX"]).endswith(
            "Found: 'Contract' (XLSX), 'ETC' (DOCX)")
        assert error_of(["GTNE EVIDENCE"], [LINK], ["HTM"]) == "the link has no web address in its 'Details'"
        for path, text in zip(sources, ["Service contract", "Invoice 7302506840 Gesamt 1.234,56 EUR", ""]):
            make_pdf(path, text)  # the last one is a scan: no text
        antalis = tool.Sample(28, 3, "446941", 2026, "", "7302506840", -1234.56)
        png = invoice_of(["Contract", "ANTALIS Rg.", "scan_001", "Costs"], ["@IT@"] * 4,
                         ["PDF", "PDF", "PDF", "XLSX"], antalis)
        assert png == stem2 + "_invoice.png" and os.path.exists(png)
        assert filecmp.cmp(stem2 + "_invoice.pdf", sources[1], shallow=False)  # the invoice is kept ...
        assert not glob.glob(stem2 + "_invoice_*.pdf")  # ... the other PDFs are deleted
        make_pdf(sources[0], "first")
        make_pdf(sources[1], "second")
        opened.clear()
        invoice_of(["a.pdf", "b.PDF"], ["@0U@"] * 2, ["", ""])  # nothing looks like an invoice: the last PDF
        assert filecmp.cmp(stem2 + "_invoice.pdf", sources[1], shallow=False)
        assert opened == []  # the type came from the titles - no Details needed
        assert tool._extension("Kopie von WhiteElements.xlsx") == "XLSX"
        assert tool._extension("[Proxy_approval_Notification]__Attachment_2.html") == "HTML"
        assert tool._extension("ANTALIS Rg. 7302506840") == tool._extension("Invoice No.12345") == ""
finally:
    os.path.isfile = real_isfile
    for name, function in real.items():
        setattr(tool, name, function)

class FakeWindow:
    """SAP window at ScreenLeft/ScreenTop whose HardCopy saves a plain picture of its size."""

    def __init__(self, left, top, width, height, grey):
        self.ScreenLeft, self.ScreenTop, self.size, self.grey = left, top, (width, height), grey

    def HardCopy(self, path, image_type):
        pix = pymupdf.Pixmap(pymupdf.csRGB, pymupdf.IRect(0, 0, *self.size), False)
        pix.clear_with(self.grey)
        pix.save(path)


# FBL4N pictures for Population: HardCopy shows one window only, so the popup with the selection
# is put onto the main window where it lies on the screen (2026-10-27)
with tempfile.TemporaryDirectory() as tmp:
    png = os.path.join(tmp, "selection.png")
    main = FakeWindow(-8, -8, 400, 300, 200)  # maximized: Windows puts the frame a bit off the screen
    for popup, (x, y) in ((FakeWindow(92, 42, 100, 50, 0), (100, 50)),
                          (FakeWindow(500, 500, 100, 50, 0), (300, 250))):  # off the edge: kept inside
        shot = tool._take_picture(types.SimpleNamespace(findById={"wnd[0]": main, "wnd[1]": popup}.get), png, True)
        pix = pymupdf.Pixmap(shot)
        assert (pix.width, pix.height) == (400, 300), pix.irect
        assert pix.pixel(x, y) == pix.pixel(x + 99, y + 49) == (0, 0, 0), (x, y)
        assert pix.pixel(x - 1, y) == pix.pixel(x, y - 1) == (200, 200, 200), (x, y)
        assert os.listdir(tmp) == ["selection.png"]  # the popup's own picture is removed
    assert tool._take_picture(types.SimpleNamespace(findById={}.get), png) is None  # logged, the run goes on

# Evidences sheet in a real hidden Excel. The rows must get a fixed height: on laptop 2 the
# tool's hidden Excel measured automatic rows as 14.76pt, a normal Excel shows them as 14.57pt,
# so the pictures slid further below their labels with every block (2026-10-22).
# Every picture must be shown at READABLE_SCALE or larger - Excel throws away the pixels of a
# smaller one on save, and it stays blurry even zoomed in (2026-10-22).
excel = win32.DispatchEx("Excel.Application")
excel.Visible = excel.ScreenUpdating = False
try:
    with tempfile.TemporaryDirectory() as tmp:
        def blank(name, width, height):
            path = os.path.join(tmp, name + ".png")
            pix = pymupdf.Pixmap(pymupdf.csRGB, pymupdf.IRect(0, 0, width, height), False)
            pix.clear_with(200)
            pix.save(path)
            return path

        document = blank("document", 1765, 1228)  # FB03 HardCopy on laptop 2
        a4 = blank("a4", 1240, 1754)  # invoice page 1 at INVOICE_DPI
        # the 3700 px GTNE page in 3 strips: row y of the page has the grey value y % 251
        rows = b"".join(bytes([y % 251]) * 1280 * 3 for y in range(3700))
        site = pymupdf.Pixmap(pymupdf.csRGB, 1280, 3700, rows, False).tobytes()
        website = tool._as_strips(site, os.path.join(tmp, "strips.png"))
        strips = pymupdf.Pixmap(website)
        assert (strips.width, strips.height) == (3 * 1280 + 2 * tool.STRIP_GAP, 1234), strips.irect
        assert strips.pixel(1280 + tool.STRIP_GAP, 0) == (1234 % 251,) * 3  # strip 2 starts with row 1234
        assert strips.pixel(2 * (1280 + tool.STRIP_GAP), 1233) == (200,) * 3  # the last strip is 2 rows short

        wb = excel.Workbooks.Add()
        while wb.Worksheets.Count < 2:
            wb.Worksheets.Add()
        # Population dates land on their own day - without a time zone pywin32 stored them 1-2 h early,
        # so 'TT.MM.JJJJ' showed the day before (review 2026-10-23)
        raw = [""] * len(tool.TEMPLATE_HEADERS)
        posting = tool.TEMPLATE_HEADERS.index("Posting Date")
        raw[tool.TEMPLATE_HEADERS.index(tool.KEY_HEADER)], raw[posting] = "1214349", "01.01.2026"
        cell = wb.Worksheets(1).Range("A1")
        cell.Value = tool.build_excel_rows([raw])[0][posting]
        assert cell.Value2 == 46023, cell.Value2  # 01.01.2026 00:00, not 31.12.2025 23:00
        # rows below the template's prepared ones get the number formats of the first data row - they were
        # 'General', so dates showed 00:00 and amounts lost their decimals (2026-10-23)
        pop = wb.Worksheets(1)
        pop.Range("H28").NumberFormat = "0.00"  # stands in for the template's date or amount format
        tool._copy_number_formats(pop, 30)
        assert pop.Range("H30").NumberFormat == pop.Range("H28").NumberFormat != pop.Range("H31").NumberFormat
        samples = [tool.Sample(28 + i, i + 1, str(1229367 + i), 2026, "") for i in range(2)]
        ev = wb.Worksheets(2)
        # like the template on laptop 2: Evidences zoomed (115% there) and another sheet active - Excel then
        # anchored the pictures to zoom-rounded rows, ~9pt higher with every block (2026-10-22)
        ev.Activate()
        wb.Windows(1).Zoom = 73  # a 15pt row is no whole number of pixels at 73%, at any screen scaling
        wb.Worksheets(1).Activate()
        files = [{"document": document, "workflow": document, "invoice": a4},
                 {"document": document, "invoice": website}]  # no workflow: the invoice keeps its place
        tool.fill_evidences(wb.Worksheets(1), ev, samples, files)
        assert wb.ActiveSheet.Name == wb.Worksheets(1).Name  # the sheet the user had open stays open
        labels = tool._label_rows(2)
        heights = {ev.Rows(r).RowHeight for r in range(tool.EVIDENCES_FIRST_ROW, labels[-1] + tool.BLOCK_ROWS)}
        assert heights == {tool.EVIDENCE_ROW_HEIGHT}, heights
        slots, x = {}, ev.Range("C1").Left
        for kind, width in tool.EVIDENCE_SLOTS.items():
            slots[kind] = (x, x + width)
            x += width
        shapes = (ev.Shapes(i) for i in range(1, ev.Shapes.Count + 1))
        for label, block in zip(labels, files):
            for kind, path in block.items():
                picture = next(shapes)
                scale = picture.Width / pymupdf.Pixmap(path).width
                assert scale >= tool.READABLE_SCALE, (kind, scale)
                assert slots[kind][0] < picture.Left and picture.Left + picture.Width < slots[kind][1], kind
                assert picture.Top + picture.Height < ev.Rows(label + tool.BLOCK_ROWS).Top, kind  # above the next label
        saved = os.path.join(tmp, "saved.xlsx")
        wb.SaveAs(saved, 51)
        wb.Close(False)
        with zipfile.ZipFile(saved) as z:
            stored = {(p.width, p.height) for p in (pymupdf.Pixmap(z.read(name)) for name in z.namelist()
                                                    if name.startswith("xl/media/"))}
            drawing = z.read("xl/drawings/drawing1.xml").decode("utf-8")
        assert stored == {(1765, 1228), (1240, 1754), (3880, 1234)}, stored  # every pixel kept
        # the row each picture is stored under - what Excel shows when the file is opened
        anchors = [(int(row) + 1, int(offset) / 12700) for row, offset in
                   re.findall(r"<xdr:from>.*?<xdr:row>(\d+)</xdr:row><xdr:rowOff>(\d+)</xdr:rowOff>", drawing)]
        assert [row for row, _ in anchors] == [labels[0] + 1] * 3 + [labels[1] + 1] * 2, anchors
        assert all(abs(offset - tool.PICTURE_MARGIN) < 1 for _, offset in anchors), anchors

        # the FBL4N pictures side by side above the Population table, the master's old one replaced
        wb = excel.Workbooks.Add()
        pop = wb.Worksheets(1)
        pop.Shapes.AddPicture(document, False, True, pop.Range("C6").Left, pop.Range("C6").Top, -1, -1)
        wb.Worksheets.Add()  # another sheet is active
        tool.fill_population_pictures(pop, [document] * 3)
        first, last = tool.POP_PICTURE_ROWS
        assert pop.Shapes.Count == 3, pop.Shapes.Count
        right = pop.Range("C1").Left
        for picture in (pop.Shapes(i) for i in range(1, 4)):
            assert right < picture.Left, (right, picture.Left)  # in order, none on another
            assert pop.Rows(first).Top < picture.Top and picture.Top + picture.Height < pop.Rows(last + 1).Top
            right = picture.Left + picture.Width
        wb.Close(False)
finally:
    excel.Quit()


def press(widget, text):
    """Presses the first button or tick box with this text in widget or below it,
    or picks this entry of a drop-down list (the year)."""
    for child in widget.winfo_children():
        kind = child.winfo_class()
        if kind in ("Button", "Checkbutton") and str(child.cget("text")) == text:
            child.invoke()  # does nothing if it is greyed out
            return True
        if kind == "Menubutton":
            menu = child.nametowidget(child.cget("menu"))
            for i in range(menu.index("end") + 1):
                if str(menu.entrycget(i, "label")) == text:
                    menu.invoke(i)
                    return True
        if press(child, text):
            return True
    return False


def clicks(*texts):
    """Stands in for a person using the period window: presses these buttons in turn."""
    def mainloop(root, n=0):
        for text in texts:
            root.update()
            assert press(root, text), f"no button '{text}'"
    return mainloop


assert tool._last_completed_quarter(dt.date(2026, 10, 22)) == (dt.date(2026, 7, 1), dt.date(2026, 9, 30))
assert tool._last_completed_quarter(dt.date(2026, 2, 1)) == (dt.date(2025, 10, 1), dt.date(2025, 12, 31))
if tool.tk:  # the period window (without tkinter the tool asks in the console instead)
    errors = []
    tool.messagebox.showerror = lambda title, text, parent=None: errors.append(text)
    real_mainloop = tool.tk.Tk.mainloop
    today = dt.date(2026, 10, 22)  # Q4 2026 is still running

    def period(*texts):
        tool.tk.Tk.mainloop = clicks(*texts)
        return tool._ask_period(today)

    def cancelled(*texts):
        try:
            period(*texts, "Cancel")
        except RuntimeError:
            return errors.pop()
        raise AssertionError(f"expected Cancel to stop the tool after {texts}")

    try:
        assert period("OK") == (dt.date(2026, 7, 1), dt.date(2026, 9, 30))  # the last completed quarter is ticked
        assert period("Q2", "OK") == (dt.date(2026, 4, 1), dt.date(2026, 9, 30))  # Q2 + Q3 = one period
        assert period("Q4", "OK") == (dt.date(2026, 7, 1), dt.date(2026, 9, 30))  # Q4 is greyed out
        assert period("2025", "Q4", "Q3", "OK") == (dt.date(2025, 7, 1), dt.date(2025, 12, 31))  # new year: ticks cleared
        assert cancelled("Q1", "OK") == "Please tick quarters that follow each other."  # Q1 + Q3
        assert cancelled("Q3", "OK") == "Please tick at least one quarter."
        assert not errors
    finally:
        tool.tk.Tk.mainloop = real_mainloop
print("All checks passed.")
