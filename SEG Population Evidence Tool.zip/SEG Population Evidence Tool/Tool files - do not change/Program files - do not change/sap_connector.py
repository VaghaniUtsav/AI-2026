# -*- coding: utf-8 -*-
"""
sap_connector.py
================
Separate module for SAP connection/login - kept apart from the main script so
the user (username/password) can change without touching the rest of the
tool.

SECURITY NOTE:
  SAP credentials are NEVER stored in plain text in the code or in a file.
  Instead the Windows Credential Manager is used (via the 'keyring'
  package) - every Windows user stores THEIR OWN password there once,
  securely encrypted by the operating system.

One-time setup per person:
    python setup_sap_credentials.py      (or double-click '3 - Save SAP password')

Usage in the main script:
    import sap_connector
    session, we_logged_in = sap_connector.get_sap_session()
"""

import os
import subprocess
import time
import logging

import win32com.client as win32
import keyring

LOGGER = logging.getLogger("upload_id_tool.sap_connector")

# ---------------------------------------------------------------------------
# CONFIGURATION - these values are the same for all users (only user/password
# differ per person and are NOT stored here, but in the
# Windows Credential Manager).
# ---------------------------------------------------------------------------
SAP_LOGON_PATHS = (r"C:\Program Files\SAP\FrontEnd\SAPGUI\saplogon.exe",  # 64-bit SAP GUI (laptop 2)
                   r"C:\Program Files (x86)\SAP\FrontEnd\SAPgui\saplogon.exe")  # 32-bit, older installations
SAP_SYSTEM_NAME = "01. SET ERP PRD"  # entry name in SAP Logon (checked 2026-10-15)
SAP_CLIENT = "100"
SAP_LANGUAGE = "EN"

KEYRING_SERVICE = "UploadIDTool_SAP"  # identifier in the Windows Credential Manager


# ---------------------------------------------------------------------------
# Credentials
# ---------------------------------------------------------------------------

def _get_credentials():
    """Reads username + password from the Windows Credential Manager."""
    user = keyring.get_password(KEYRING_SERVICE, "username")
    password = keyring.get_password(KEYRING_SERVICE, user) if user else None

    if not user or not password:
        raise RuntimeError(
            "Your SAP user and password are not saved on this PC yet. "
            "Please double-click '3 - Save SAP password' once, then start again."
        )
    return user, password


# ---------------------------------------------------------------------------
# SAP processes / GUI
# ---------------------------------------------------------------------------

def _close_existing_sap():
    for proc in ("saplogon.exe", "sapgui.exe"):
        try:
            subprocess.run(["taskkill", "/f", "/im", proc],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError as e:  # 'WinError 5' on c.liptay's PC: Windows doesn't let Python start taskkill (2026-10-27)
            LOGGER.info(f"SAP could not be closed ({e}) - going on with the SAP Logon that is open, if any.")
            return
    LOGGER.info("Existing SAP processes terminated.")
    time.sleep(2)


def _wait_for_sap_gui(timeout=60):
    for _ in range(timeout):
        try:
            return win32.GetObject("SAPGUI")
        except Exception:
            time.sleep(1)
    raise RuntimeError(f"SAP GUI was not available after {timeout}s - is SAP GUI scripting switched on "
                       f"(see the guide, one-time setup)?")


def _scripting_engine(sap_gui):
    try:
        return sap_gui.GetScriptingEngine
    except Exception as e:
        raise RuntimeError(f"The tool can't control SAP - SAP GUI scripting is probably switched off on this "
                           f"PC (see the guide, one-time setup). ({e})")


def _try_get_existing_session():
    """An open, logged-in SAP session to reuse (no restart/login needed, no
    interruption of the user's ongoing work) - but only one of SAP_SYSTEM_NAME,
    SAP_CLIENT and SAP_LANGUAGE: another system or client gives the wrong data,
    another language has none of the English screen texts the tool looks for.
    None if nobody is logged in - then the tool logs on by itself."""
    try:
        sap_gui_auto = win32.GetObject("SAPGUI")
    except Exception:
        return None  # SAP is not running
    application = _scripting_engine(sap_gui_auto)
    found = []
    for i in range(application.Children.Count):
        connection = application.Children(i)
        for j in range(connection.Children.Count):
            session = connection.Children(j)
            info = session.Info
            if not info.User:  # login screen - not logged in yet
                continue
            if (connection.Description, info.Client, info.Language.upper()) == (SAP_SYSTEM_NAME, SAP_CLIENT, SAP_LANGUAGE):
                LOGGER.info(f"Existing logged-in SAP session found (user: {info.User}).")
                return session
            found.append(f"'{connection.Description}' client {info.Client} language {info.Language}")
    if found:  # stop - sap_login would close these SAP windows, maybe with unsaved work
        raise RuntimeError(
            f"SAP is open, but not in '{SAP_SYSTEM_NAME}', client {SAP_CLIENT}, language {SAP_LANGUAGE} "
            f"(open: {'; '.join(found)}). Please save your work in SAP, close SAP completely (all SAP "
            f"windows) and start again - the tool then logs on to SAP by itself.")
    return None


# ---------------------------------------------------------------------------
# Login
# ---------------------------------------------------------------------------

def sap_login(system_name=None, client=None, language=None):
    """Closes SAP GUI (if open), restarts it and logs in with the
    credentials stored in the Windows Credential Manager.
    Returns the active, logged-in SAP session."""
    system_name = system_name or SAP_SYSTEM_NAME
    client = client or SAP_CLIENT
    language = language or SAP_LANGUAGE
    saplogon = next((p for p in SAP_LOGON_PATHS if os.path.exists(p)), None)  # before SAP is closed
    if not saplogon:
        raise RuntimeError(f"SAP Logon was not found on this PC ({' or '.join(SAP_LOGON_PATHS)}). "
                           f"Is SAP GUI installed? If it is, send this message to Utsav.")
    user, password = _get_credentials()

    _close_existing_sap()

    try:
        subprocess.Popen(saplogon)
    except OSError as e:  # the same PC may not let Python start any program
        raise RuntimeError(f"Windows did not let the tool start SAP Logon ({e}). Please log on to SAP by hand "
                           f"('{system_name}', client {client}, language {language}) and start the tool again - "
                           f"it then uses your open SAP. Please also tell Utsav about this message.")
    LOGGER.info("SAP Logon started.")
    time.sleep(10)

    sap_gui_auto = _wait_for_sap_gui()
    application = _scripting_engine(sap_gui_auto)
    try:
        connection = application.OpenConnection(system_name, True)
    except Exception as e:
        raise RuntimeError(f"SAP could not connect to '{system_name}' ({e}). Is the PC in the company network "
                           f"(VPN), and is there an entry with exactly this name in SAP Logon?")
    session = connection.Children(0)

    session.findById("wnd[0]/usr/txtRSYST-MANDT").text = client
    session.findById("wnd[0]/usr/txtRSYST-BNAME").text = user
    session.findById("wnd[0]/usr/pwdRSYST-BCODE").text = password
    session.findById("wnd[0]/usr/txtRSYST-LANGU").text = language
    session.findById("wnd[0]").sendVKey(0)
    LOGGER.info("Login data sent, waiting for processing ...")
    time.sleep(5)

    # Click away any popups (e.g. "Already logged on elsewhere")
    for _ in range(5):
        try:
            if session.Children.Count > 1:
                popup = session.Children(1)
                popup.sendVKey(0)
                time.sleep(1)
            else:
                break
        except Exception:
            break

    # Actually verify success instead of just assuming it
    try:
        logged_in_user = session.Info.User
    except Exception as e:
        raise RuntimeError(f"SAP login could not be verified: {e}")

    if not logged_in_user:
        raise RuntimeError(
            "SAP logon failed - the saved SAP password is probably wrong or has expired. Don't start the "
            "tool again yet: after a few wrong passwords SAP locks your user. Log on to SAP by hand once "
            "(set a new password if SAP asks for one), then double-click '3 - Save SAP password' and start again."
        )

    LOGGER.info(f"SAP login successful (user: {logged_in_user}).")
    return session


def get_sap_session(force_relogin: bool = False):
    """Main entry point for the main script. Returns a tuple:
        (session, we_logged_in)
    'we_logged_in' is True if this function started SAP itself and
    logged in - then it may also log out again at the end.
    For a session the user already had open it is False (then do NOT
    log out, so the user's ongoing work is not disturbed)."""
    if not force_relogin:
        existing = _try_get_existing_session()
        if existing:
            return existing, False
    return sap_login(), True


def sap_logout(session):
    """Logs the user out of SAP and ends the session (via the system
    menu /nend or the logoff command). Errors are only logged, not
    raised - a failed logout should not mark an otherwise successful
    run as failed."""
    try:
        # /nex ends ALL SAP sessions and closes SAP GUI cleanly.
        session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
        session.findById("wnd[0]").sendVKey(0)
        LOGGER.info("SAP logout done (/nex).")
    except Exception as e:
        LOGGER.warning(f"SAP logout not possible: {e}")
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    session, logged_in = get_sap_session()
    print("Connected as:", session.Info.User)
