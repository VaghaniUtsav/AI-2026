# -*- coding: utf-8 -*-
"""
setup_sap_credentials.py
=========================
One-time setup of the personal SAP credentials for the
Upload ID Tool. Every user must run this ONCE on their own Windows account
(and again if the SAP password changes later).

The input is NOT STORED in plain text (neither in a file nor
in the code), but stored securely encrypted via the Windows Credential Manager
(package 'keyring'). The password is typed hidden; only if the terminal
cannot hide input does the script fall back to visible typing (with a
warning). It is not stored anywhere in plain text afterwards.

Run with:
    python setup_sap_credentials.py
"""

import getpass

import keyring

KEYRING_SERVICE = "UploadIDTool_SAP"


def main():
    print("=" * 60, flush=True)
    print("Save your SAP user and password for the SEG tool", flush=True)
    print("=" * 60, flush=True)
    print(
        "Your input is stored securely in the Windows Credential Manager\n"
        "- NOT in plain text, NOT in a file, NOT in the code.\n",
        flush=True,
    )

    user = input("SAP username: ").strip()
    print(f"(Username '{user}' received - continuing with the password ...)", flush=True)
    if not user:
        print("Cancelled: no username entered.", flush=True)
        return

    try:
        password = getpass.getpass("SAP password (typing is hidden): ").strip()
        # twice: a typo would only show as a failed SAP logon, and a few of those lock the SAP user
        if password and getpass.getpass("The same password again: ").strip() != password:
            print("Cancelled: the two passwords are not the same - nothing saved. Please start again.", flush=True)
            return
    except Exception:  # terminal cannot hide input - visible, as a warned fallback
        print(">>> Warning: the password will now be entered VISIBLY (not", flush=True)
        print(">>> hidden) - please make sure nobody is watching.\n", flush=True)
        password = input("SAP password: ").strip()
    if not password:
        print("Cancelled: no password entered.", flush=True)
        return
    print("(Password received.)", flush=True)

    print("Saving username in the Credential Manager ...", flush=True)
    try:
        keyring.set_password(KEYRING_SERVICE, "username", user)
        print("... username saved.", flush=True)
    except Exception as e:
        print(f"ERROR saving the username: {e}", flush=True)
        return

    print("Saving password in the Credential Manager ...", flush=True)
    try:
        keyring.set_password(KEYRING_SERVICE, user, password)
        print("... password saved.", flush=True)
    except Exception as e:
        print(f"ERROR saving the password: {e}", flush=True)
        return

    print(f"\nSaved for user '{user}'.", flush=True)
    print("Double-click '3 - Save SAP password' again whenever", flush=True)
    print("your SAP password changes.", flush=True)


if __name__ == "__main__":
    main()
