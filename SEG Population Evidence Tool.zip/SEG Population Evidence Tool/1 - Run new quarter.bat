@echo off
title SEG tool - running, please do not close this window
rem Every quarter: SAP list into Population, new samples, evidence pictures. See the guide.
set PY="%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe"
if not exist %PY% set PY=py -V:3.14
%PY% "%~dp0population_evidence_tool.py"
if errorlevel 1 pause
