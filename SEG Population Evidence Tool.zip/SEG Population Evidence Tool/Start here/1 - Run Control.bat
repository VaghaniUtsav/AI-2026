@echo off
title SEG tool - running, please do not close this window
rem Every quarter: SAP list into a new Excel file in 'Excel results', new samples, evidence pictures. See the guide.
set PY="%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe"
if not exist %PY% set PY=py -V:3.14
%PY% -B "%~dp0..\Program files - do not change\population_evidence_tool.py"
if errorlevel 1 pause
