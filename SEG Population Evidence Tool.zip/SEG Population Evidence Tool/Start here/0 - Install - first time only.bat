@echo off
title SEG tool - installing
rem One time on a new PC: gets Python 3.14 and the parts the tool needs. No admin rights needed. See the guide.
rem Python is python.org's own zip, unpacked where the Python install manager puts it - no app package, no questions (2026-11-02).
rem Newer 3.14: version and sha256 of pythoncore-3.14-64 are in https://www.python.org/ftp/python/index-windows.json
rem pip runs quietly - its long lists and harmless 'not on PATH' warnings worried people. Errors still show (2026-11-02).
set PYVER=3.14.10
set PYSHA=cc28026a650970cc1570bb127312f1f9634eb67abfe157ae6ca1acbbc627d091
set PYDIR=%LOCALAPPDATA%\Python\pythoncore-3.14-64
set PY="%PYDIR%\python.exe"
set ZIP="%TEMP%\python-%PYVER%-amd64.zip"
echo Step 1 of 3: Python 3.14
if exist %PY% (echo    already installed& goto parts)
echo    downloading from python.org - about 33 MB ...
rem revoke-best-effort: company proxies often block the certificate revocation check; the sha256 check below stays strict
"%SystemRoot%\System32\curl.exe" -fsSL --ssl-revoke-best-effort --retry 2 -o %ZIP% https://www.python.org/ftp/python/%PYVER%/python-%PYVER%-amd64.zip
if errorlevel 1 goto failed
certutil -hashfile %ZIP% SHA256 | findstr /i %PYSHA% >nul
if errorlevel 1 (echo    the downloaded file is not the expected one from python.org & goto failed)
if not exist "%PYDIR%" mkdir "%PYDIR%"
"%SystemRoot%\System32\tar.exe" -xf %ZIP% -C "%PYDIR%"
if errorlevel 1 goto failed
del %ZIP%
if not exist %PY% goto failed
echo    done
:parts
echo Step 2 of 3: the parts the tool needs - about 150 MB, this takes a few minutes ...
%PY% -m pip install --quiet --disable-pip-version-check --no-warn-script-location pywin32 keyring pymupdf playwright
if errorlevel 1 goto failed
echo    done
echo Step 3 of 3: checking that everything works ...
%PY% -c "import win32com.client, keyring, pymupdf, playwright.sync_api"
if errorlevel 1 goto failed
set EDGE=
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set EDGE=1
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set EDGE=1
if not defined EDGE (echo    Microsoft Edge was not found - the tool needs it for invoices that are web links. & goto failed)
echo    done
echo.
echo ALL INSTALLED - you can close this window.
pause
exit /b

:failed
echo.
echo SOMETHING WENT WRONG - please send a screenshot of this window to Utsav.
pause
