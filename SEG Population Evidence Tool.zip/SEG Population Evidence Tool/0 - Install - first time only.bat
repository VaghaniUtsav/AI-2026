@echo off
title SEG tool - installing
rem One time on a new PC, after Python 3.14 is installed: adds the parts the tool needs. See the guide.
set PY="%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe"
if not exist %PY% set PY=py -V:3.14
%PY% -m pip install pywin32 keyring pymupdf playwright
if errorlevel 1 (echo. & echo SOMETHING WENT WRONG - please send a screenshot of this window to Utsav.) else (echo. & echo ALL INSTALLED - you can close this window.)
pause
