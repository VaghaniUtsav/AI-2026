@echo off
title SEG tool - taking the pictures again, please do not close this window
rem Same samples - only the SAP pictures and the Evidences sheet again, in the newest file in 'Excel results'. See the guide.
set PY="%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe"
if not exist %PY% set PY=py -V:3.14
%PY% -B "%~dp0Tool files - do not change\Program files - do not change\population_evidence_tool.py" --evidences-only
if errorlevel 1 pause
