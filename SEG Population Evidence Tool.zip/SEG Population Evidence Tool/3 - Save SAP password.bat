@echo off
title SEG tool - save SAP password
rem Once on a new PC, and again whenever the SAP password changes. See the guide.
set PY="%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe"
if not exist %PY% set PY=py -V:3.14
%PY% "%~dp0setup_sap_credentials.py"
pause
