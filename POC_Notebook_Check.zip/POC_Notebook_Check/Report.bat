@echo off
setlocal
rem No "cd" into this folder: cmd.exe cannot do that on a network path (\\server\share), so use full paths.
title Inventaris-Formular POC - Report
if not exist "%~dp0App\Program\Notebook_Check.exe" goto not_unzipped

echo ==============================================================
echo  Inventaris-Formular - Report fuer HR / report for HR
echo ==============================================================
echo  1. Liest Data\Report Data.xlsx / reads Data\Report Data.xlsx
echo  2. Zaehlt jeden Mitarbeiter in genau eine Gruppe /
echo     counts every employee into exactly one group
echo  3. Oeffnet einen Outlook-Entwurf, nichts wird von selbst gesendet /
echo     opens an Outlook draft, nothing is sent by itself
"%~dp0App\Program\Notebook_Check.exe" --report
if errorlevel 1 goto error
echo.
echo Fertig. / Done.
pause
exit /b 0

:error
echo.
echo FEHLER / ERROR - siehe Meldung oben / see the message above.
pause
exit /b 1

:not_unzipped
echo Bitte zuerst die Zip-Datei entpacken: Rechtsklick auf die Zip-Datei, dann "Alle extrahieren".
echo Danach Start.bat im entpackten Ordner starten.
echo Please unzip first: right-click the zip file, then "Extract All". Then run Start.bat from that folder.
pause
exit /b 1
