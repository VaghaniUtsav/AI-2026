r"""The reminder run as a window: the same lists, rules and logs as send_reminders.py, with clicks instead of typing.

Start.bat opens it with pythonw, so no black box stays open. It takes the same arguments as send_reminders.py;
without them it uses the POC folder's Data, Reports and Logs.
Design: docs/superpowers/specs/2026-11-05-hr-poc-window-design.md
"""
import contextlib
import ctypes
import os
import tkinter as tk
import traceback
from tkinter import font, messagebox, ttk

TITLE = "Inventaris-Formular – Erinnerungen / Reminders"

try:
    import send_reminders as sr
except SystemExit as e:  # openpyxl missing: pythonw has no console, so say it in a box
    tk.Tk().withdraw()
    messagebox.showerror(TITLE, str(e))
    raise

YELLOW = ("#FFF4CE", "#5C4400")  # (background, text): test mode
GREEN = ("#DFF6DD", "#0E5A0E")  # real mode; a run without failures
RED = ("#FDE7E9", "#A4262C")  # a message that stops the run; failed mails
GREY = "#605E5C"  # notes under the list
SHARED = "  (geteiltes Postfach / shared mailbox)"
KNOX_SENDER = "Knox – vaghani.u@partner.samsung.com"  # the Knox flow always sends as its owner
SENT = "gesendet / sent"
FAILED = "Fehler / failed: {}"


def first(items, count):
    """items[:count], plus '… und N weitere / and N more' when there are more (the run log has them all)."""
    rest = len(items) - count
    return items[:count] + ([f"… und {rest} weitere / and {rest} more"] if rest > 0 else [])


class Window:
    """One reminder run in a window. dispatch and post stand in for Outlook and Knox in tests; confirm is the Yes/No
    box, called like messagebox.askyesno."""

    def __init__(self, root, args, dispatch=None, post=None, confirm=messagebox.askyesno):
        self.root, self.args, self.dispatch, self.post, self.confirm = root, args, dispatch, post, confirm
        self.plan = self.outlook = self.knox = None
        self.senders, self.sending, self.done = [], False, 0
        scale = root.winfo_fpixels("1i") / 96  # sizes below are for 100 %; Windows may be set to 125 % or 150 %

        def px(size):
            return round(size * scale)

        root.title(TITLE)
        root.geometry(f"{px(880)}x{px(640)}")
        root.minsize(px(660), px(480))
        root.protocol("WM_DELETE_WINDOW", self.close)
        root.report_callback_exception = self.crash
        for name in ("TkDefaultFont", "TkTextFont", "TkHeadingFont"):
            font.nametofont(name).configure(size=10)
        base = font.nametofont("TkDefaultFont")
        bold = (base.cget("family"), 10, "bold")
        style = ttk.Style(root)
        style.configure("Treeview", rowheight=base.metrics("linespace") + px(8))
        style.configure("Send.TButton", font=bold, padding=(px(14), px(6)))

        frame = ttk.Frame(root, padding=px(16))
        frame.pack(fill="both", expand=True)
        self.banner = tk.Label(frame, anchor="w", justify="left", padx=px(12), pady=px(10), wraplength=px(780),
                               font=bold)
        self.banner.pack(fill="x")
        self.plain = self.banner.cget("bg")
        line = ttk.Frame(frame)
        line.pack(fill="x", pady=(px(14), 0))
        ttk.Label(line, text="Absender / Send from:").pack(side="left")
        self.sender = ttk.Combobox(line, state="disabled", width=56)
        self.sender.pack(side="left", padx=(px(8), 0))
        self.sender.bind("<MouseWheel>", lambda event: "break")  # scrolling the page must not change the sender
        self.counts = ttk.Label(frame)
        self.counts.pack(anchor="w", pady=(px(14), px(6)))
        # bottom up: the bar, the buttons and the notes keep their place; the list gets whatever height is left
        bar = ttk.Frame(frame)
        bar.pack(side="bottom", fill="x", pady=(px(10), 0))
        self.progress = ttk.Progressbar(bar, mode="determinate")
        self.progress.pack(side="left", fill="x", expand=True)
        self.progress_text = ttk.Label(bar, width=9, anchor="e")
        self.progress_text.pack(side="left")
        self.buttons = ttk.Frame(frame)
        self.buttons.pack(side="bottom", fill="x", pady=(px(12), 0))
        self.data_button = ttk.Button(self.buttons, text="Daten-Ordner öffnen / Open Data folder",
                                      command=self.open_data)
        self.data_button.pack(side="left")
        self.reload_button = ttk.Button(self.buttons, text="Neu laden / Reload", command=self.reload)
        self.reload_button.pack(side="left", padx=(px(8), 0))
        self.send_button = ttk.Button(self.buttons, style="Send.TButton", command=self.send_all)
        self.send_button.pack(side="right")
        self.message = tk.Label(frame, anchor="w", justify="left", padx=px(12), pady=px(8), wraplength=px(780))
        self.message_pad = (px(10), 0)
        self.notes = ttk.Label(frame, foreground=GREY, wraplength=px(780), justify="left")
        self.notes.pack(side="bottom", anchor="w", pady=(px(6), 0))
        box = ttk.Frame(frame)
        box.pack(fill="both", expand=True)
        self.table = ttk.Treeview(box, columns=("name", "email", "status"), show="headings", selectmode="none",
                                  height=5)
        for column, heading, width in (("name", "Name", 220), ("email", "E-Mail", 280), ("status", "Status", 280)):
            self.table.heading(column, text=heading, anchor="w")
            self.table.column(column, width=px(width), anchor="w")
        self.table.tag_configure("sent", foreground=GREEN[1])
        self.table.tag_configure("failed", foreground=RED[1])
        scroll = ttk.Scrollbar(box, command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.table.pack(side="left", fill="both", expand=True)
        # after Tk has put the window on screen (after_idle runs before that): starting a closed Outlook can take
        # half a minute, and an empty screen meanwhile makes people double-click Start.bat again
        root.after(50, self.reload)

    def reload(self):
        """Read the settings and both lists (again), show them, and connect to Outlook or Knox."""
        chosen = self.sender.get()  # Reload keeps the sender the user picked
        self.plan = self.outlook = self.knox = None
        self.table.delete(*self.table.get_children())
        for label in (self.banner, self.counts, self.notes, self.progress_text):
            label.config(text="")
        self.banner.config(bg=self.plain)
        self.progress.config(value=0)
        self.sender.config(values=[], state="disabled")
        self.sender.set("")
        self.send_button.config(text="Senden / Send", state="disabled")
        self.say("")
        try:
            self.plan = sr.prepare(self.args)
        except SystemExit as e:
            return self.stop(e)
        sr.show(self.plan)  # the run log records what the window shows
        self.show_plan()
        if not self.plan.mails:
            return
        try:
            self.connect(chosen)
        except SystemExit as e:
            return self.stop(e)
        self.send_button.config(state="normal")

    def show_plan(self):
        plan, texts = self.plan, self.plan.texts
        if texts["test_mode"]:
            text = f"TESTMODUS / TEST MODE – alle Mails gehen an / all mails go to {texts['test_address']}"
            colours = YELLOW
        else:
            text = "ECHTER VERSAND / REAL MODE – Mails gehen an die echten Adressen / mails go to the real addresses"
            colours = GREEN
        self.banner.config(text=text, bg=colours[0], fg=colours[1])
        self.counts.config(text=f"Mitarbeiter / Employees: {plan.employees}      Formulare / Forms: {plan.forms}      "
                                f"Erinnerungen / Reminders: {len(plan.mails)}")
        for mail in plan.mails:  # meant_for is unique: build_reminders keeps one reminder per address
            self.table.insert("", "end", iid=mail.meant_for, values=(mail.name, mail.meant_for, ""))
        notes = []
        if plan.no_email:
            notes.append("Ohne E-Mail, keine Erinnerung / no email, no reminder: "
                         + ", ".join(first([name or "(ohne Namen / no name)" for name in plan.no_email], 10)))
        if plan.demo:
            notes.append(f"Demo übersprungen / demo skipped: {plan.demo}")
        if not plan.mails:
            notes.append("Nichts zu senden / nothing to send")
        self.notes.config(text="\n".join(notes))
        count = len(plan.mails)
        self.send_button.config(text=f"{count} Erinnerung(en) senden / Send {count} reminder(s)")

    def connect(self, chosen=""):
        """Outlook: every address it can send from, in the dropdown, chosen first if it is still there. Knox: the
        key, and its one sender."""
        if self.plan.texts["via"] == "knox":
            self.knox = sr.knox_sender(sr.knox_key(self.args.key_file), self.post)
            self.sender.config(values=[KNOX_SENDER])
            self.sender.current(0)  # stays disabled: nothing to choose
            return
        self.sender.set("Outlook wird verbunden … / connecting to Outlook …")
        self.root.update_idletasks()
        self.outlook, self.senders = sr.open_outlook(self.dispatch)
        shown = [address + ("" if account is not None else SHARED) for address, account in self.senders]
        self.sender.config(values=shown, state="readonly")
        self.sender.current(shown.index(chosen) if chosen in shown else 0)

    def send_all(self):
        """Yes/No, then every mail, each row showing how it went."""
        plan, texts = self.plan, self.plan.texts
        try:
            sr.check_writable(plan.log_path)
        except SystemExit as e:  # open in Excel: close it there, then click Send again
            print(e)
            return self.say(str(e), RED)
        count, test = len(plan.mails), texts["test_mode"]
        address, account = (KNOX_SENDER, None) if self.knox else self.senders[self.sender.current()]
        if test:
            question = (f"{count} Erinnerung(en) senden?\nTESTMODUS: alle gehen an {texts['test_address']}.\n\n"
                        f"Send {count} reminder(s)?\nTEST MODE: all go to {texts['test_address']}.")
        else:
            question = (f"{count} Erinnerung(en) senden?\nECHTER VERSAND: {count} echte Personen bekommen eine Mail."
                        f"\n\nSend {count} reminder(s)?\nREAL MODE: {count} real people will get an email.")
        question += f"\n\nAbsender / From: {address}"
        if not self.confirm(TITLE, question, icon="question" if test else "warning", default="yes" if test else "no"):
            print("Nichts gesendet / Nothing sent")
            return
        print("Ja / Yes")
        if self.knox:
            send = self.knox
        else:
            print(f"Absender / sender: {address}")
            send = sr.outlook_send(self.outlook, address, account)
        self.sending, self.done, self.errors = True, 0, []
        for widget in (self.send_button, self.reload_button, self.sender):
            widget.config(state="disabled")
        self.progress.config(maximum=count, value=0)
        try:
            sent, failed = sr.deliver(plan.mails, send, plan.log_path, self.report)
        except SystemExit as e:
            return self.stop(e)
        finally:
            self.sending = False
            self.reload_button.config(state="normal")
        print(f"Gesendet / sent: {sent}   Fehler / failed: {failed}   {sr._held(plan)}")
        done = f"Fertig / Done – gesendet / sent: {sent}, Fehler / failed: {failed}"
        if failed:  # each reason once, in full: the Status column cuts long ones off
            self.say("\n".join([done + " (rote Zeilen / red rows):", *first(list(dict.fromkeys(self.errors)), 5)]), RED)
        else:
            self.say(done, GREEN)

    def report(self, mail, error):
        """One mail done: its row says how it went, the bar moves on, the window repaints."""
        if error is None:
            self.table.set(mail.meant_for, "status", SENT)
            self.table.item(mail.meant_for, tags=("sent",))
        else:
            print(f"Fehler beim Senden an / failed to send to {sr._who(mail)}: {error}")
            self.errors.append(str(error))
            self.table.set(mail.meant_for, "status", FAILED.format(error))
            self.table.item(mail.meant_for, tags=("failed",))
        self.table.see(mail.meant_for)
        self.done += 1
        self.progress.config(value=self.done)
        self.progress_text.config(text=f"{self.done} / {len(self.plan.mails)}")
        # ponytail: sends on the window's own thread and repaints between mails (Outlook's COM objects belong to
        # this thread); a worker thread would need COM marshalling - only if a single mail ever takes long
        self.root.update()

    def stop(self, message):
        """A message that stops the run, as the console version would show it: in red, into the run log, no Send."""
        print(message)
        self.say(str(message), RED)
        self.send_button.config(state="disabled")

    def say(self, text, colours=None):
        """A coloured message above the buttons; empty text hides it."""
        if not text:
            self.message.pack_forget()
            return
        self.message.config(text=text, bg=colours[0], fg=colours[1])
        self.message.pack(side="bottom", fill="x", pady=self.message_pad, after=self.buttons)  # right above them

    def open_data(self):
        try:
            os.startfile(self.args.employees.parent)
        except OSError as e:
            self.say(f"Ordner nicht geöffnet / folder not opened: {e}", RED)

    def close(self):
        if not self.sending:  # mid-run the rest would be dropped without a word; it closes once the run is done
            self.root.destroy()

    def crash(self, kind, error, tb):
        """An unexpected error in a click or the first load: the details into the run log, one line in the window."""
        print("".join(traceback.format_exception(kind, error, tb)))
        self.say(f"Unerwarteter Fehler / unexpected error: {error} – Details: App\\Logs", RED)


def main(argv=None, **stand_ins):
    """Show the window until it is closed. stand_ins (dispatch, post, confirm) are for tests."""
    with contextlib.suppress(AttributeError, OSError):
        ctypes.windll.shcore.SetProcessDpiAwareness(1)  # sharp text on scaled screens (125 %, 150 %)
    args = sr.parse_args(argv)
    tee = sr.start_run_log(args.logs_folder, None)  # pythonw has no console: only the run log
    with tee.log if tee else contextlib.nullcontext(), contextlib.redirect_stdout(tee):
        root = tk.Tk()
        try:
            Window(root, args, **stand_ins)
        except Exception as e:  # before the window is up: no red box yet, and pythonw has no console
            print(traceback.format_exc())
            root.withdraw()
            messagebox.showerror(TITLE, f"Unerwarteter Fehler / unexpected error: {e}\nDetails: App\\Logs")
            root.destroy()
            return
        root.mainloop()


if __name__ == "__main__":
    main()
