@echo off
setlocal
cd /d "%~dp0"
title Notebook-Inventur POC - Einrichtung / Setup
call :find_python
if not defined PY goto no_python
echo Python gefunden / found: %PY%
echo Installiere / installing: openpyxl, requests ...
%PY% -m pip install --upgrade openpyxl requests
if errorlevel 1 goto error
echo.
echo Fertig. Jetzt Start.bat doppelklicken. / Done. Now double-click Start.bat.
pause
exit /b 0

:error
echo.
echo FEHLER: Installation fehlgeschlagen - bitte die Meldung oben der IT zeigen.
echo ERROR: installation failed - please show the message above to IT.
pause
exit /b 1

:no_python
echo Python wurde nicht gefunden. Bitte bei der IT "Python 3" anfordern.
echo Python was not found. Please ask IT to install "Python 3".
pause
exit /b 1

:find_python
set "PY="
py --version >nul 2>&1 && set "PY=py" && exit /b 0
python --version >nul 2>&1 && set "PY=python" && exit /b 0
exit /b 0
