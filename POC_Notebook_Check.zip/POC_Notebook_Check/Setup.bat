@echo off
setlocal
rem Run once per PC: installs Python for this user if it is missing (no admin rights needed), then openpyxl, requests
rem and pywin32 (lets the program send through Outlook).
rem No "cd" into this folder: cmd.exe cannot do that on a network path (\\server\share).
rem "call" in front of py and curl: also works when they are .cmd files (the tests use such stand-ins).
title Inventaris-Formular POC - Einrichtung / Setup
set "PY_VERSION=3.14.7"
rem SHA-256 of the official python.org installer: any other download is deleted and never started
set "PY_SHA256=9d9eb2709ef81bf5cd30db3c2096bdbc4ea10087c22e62f27d356b36f6ae9649"
set "PY_URL=https://www.python.org/ftp/python/%PY_VERSION%/python-%PY_VERSION%-amd64.exe"
set "INSTALLER=%TEMP%\python-%PY_VERSION%-amd64.exe"

call :find_python
if defined PY goto packages

echo Python fehlt - wird von python.org geladen und installiert (ca. 30 MB, einige Minuten) ...
echo Python is missing - downloading and installing it from python.org (about 30 MB, a few minutes) ...
call curl -L -f -s -S -o "%INSTALLER%" "%PY_URL%"
if errorlevel 1 goto download_failed
set "HASH="
for /f "skip=1 delims=" %%H in ('certutil -hashfile "%INSTALLER%" SHA256') do if not defined HASH set "HASH=%%H"
if defined HASH set "HASH=%HASH: =%"
if /i not "%HASH%"=="%PY_SHA256%" goto wrong_download
start "" /wait "%INSTALLER%" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 InstallLauncherAllUsers=0 Include_test=0
set "RC=%errorlevel%"
del "%INSTALLER%" 2>nul
call :find_python
if not defined PY goto install_failed

:packages
echo Python gefunden / found: %PY%
echo Installiere / installing: openpyxl, requests, pywin32 ...
call %PY% -m pip install --upgrade --disable-pip-version-check openpyxl requests pywin32
if errorlevel 1 goto error
echo.
echo Fertig. Jetzt Start.bat doppelklicken. / Done. Now double-click Start.bat.
pause
exit /b 0

:download_failed
del "%INSTALLER%" 2>nul
echo.
echo FEHLER: Download fehlgeschlagen - Internet oder python.org nicht erreichbar. Spaeter erneut versuchen oder die IT fragen.
echo ERROR: download failed - no internet or python.org not reachable. Try again later or ask IT.
pause
exit /b 1

:wrong_download
del "%INSTALLER%" 2>nul
echo.
echo FEHLER: Die geladene Datei ist nicht das offizielle Python - sie wurde geloescht und NICHT gestartet.
echo ERROR: the download is not the official Python - it was deleted and NOT started.
pause
exit /b 1

:install_failed
echo.
echo FEHLER: Python-Installation fehlgeschlagen (Code %RC%) - bitte die IT fragen.
echo ERROR: installing Python failed (code %RC%) - please ask IT.
pause
exit /b 1

:error
echo.
echo FEHLER: Installation von openpyxl/requests/pywin32 fehlgeschlagen - bitte die Meldung oben der IT zeigen.
echo ERROR: installing openpyxl/requests/pywin32 failed - please show the message above to IT.
pause
exit /b 1

:find_python
rem the Python launcher "py", else where this file installs Python (PATH may not know it yet)
set "PY="
call py --version >nul 2>&1 && set "PY=py" && exit /b 0
if exist "%LOCALAPPDATA%\Programs\Python\Python314\python.exe" set PY="%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
exit /b 0
