@echo off
setlocal
cd /d "%~dp0"
title Notebook-Inventur POC
if not exist "Programm\check_inventory.py" goto not_unzipped
call :find_python
if not defined PY goto no_python

echo ==============================================================
echo  Notebook-Inventur - Proof of Concept (nur Testdaten / dummy data)
echo ==============================================================
echo.
echo Schritt 1 von 3 / Step 1 of 3: Pruefung / check
echo --------------------------------------------------------------
%PY% Programm\check_inventory.py --myseg "Daten\MySEG Meldungen.xlsx" --inventory "Daten\gesamte NB-Liste.xlsx" --directory "Daten\Mitarbeiterverzeichnis.xlsx" --out Berichte --open
if errorlevel 1 goto error
echo.
echo Schritt 2 von 3 / Step 2 of 3: Bericht pruefen / review the report
echo --------------------------------------------------------------
echo Der Pruefbericht ist jetzt in Excel geoeffnet.
echo Zeilen, die KEINE Erinnerung bekommen sollen, loeschen und speichern.
echo The report is open in Excel. Delete rows that should NOT get a reminder, then save.
pause
echo.
echo Schritt 3 von 3 / Step 3 of 3: Senden ueber Knox / send through Knox
echo --------------------------------------------------------------
%PY% Programm\send_reminders.py --reports Berichte --texts Programm\Email_Texte.ini
if errorlevel 1 goto error
echo.
echo Fertig. / Done.
pause
exit /b 0

:error
echo.
echo FEHLER / ERROR - siehe Meldung oben / see the message above.
pause
exit /b 1

:not_unzipped
echo Bitte zuerst die Zip-Datei entpacken: Rechtsklick auf die Zip-Datei, dann "Alle extrahieren".
echo Danach Start.bat im entpackten Ordner starten.
echo Please unzip first: right-click the zip file, then "Extract All". Then run Start.bat from that folder.
pause
exit /b 1

:no_python
echo Python wurde nicht gefunden. Bitte zuerst Setup.bat ausfuehren oder die IT fragen.
echo Python was not found. Run Setup.bat first or ask IT.
pause
exit /b 1

:find_python
set "PY="
py --version >nul 2>&1 && set "PY=py" && exit /b 0
python --version >nul 2>&1 && set "PY=python" && exit /b 0
exit /b 0
