@echo off
setlocal
rem No "cd" into this folder: cmd.exe cannot do that on a network path (\\server\share), so use full paths.
title Inventaris-Formular POC
if not exist "%~dp0Programm\send_reminders.py" goto not_unzipped
rem The folder brings its own Python: nothing has to be installed on the PC.
set "PY=%~dp0Programm\python\python.exe"
if not exist "%PY%" goto no_python

echo ==============================================================
echo  Inventaris-Formular - Erinnerungen / reminders (Proof of Concept)
echo ==============================================================
echo.
echo Vergleicht "MySEG All Employee List" mit "MySEG Inventaris Form List".
echo Wer das Formular noch nicht ausgefuellt hat, bekommt eine Erinnerung.
echo Compares the two lists in "Daten"; everyone without a form gets a reminder.
echo --------------------------------------------------------------
"%PY%" "%~dp0Programm\send_reminders.py"
if errorlevel 1 goto error
echo.
echo Fertig. / Done.
pause
exit /b 0

:error
echo.
echo FEHLER / ERROR - siehe Meldung oben / see the message above.
pause
exit /b 1

:not_unzipped
echo Bitte zuerst die Zip-Datei entpacken: Rechtsklick auf die Zip-Datei, dann "Alle extrahieren".
echo Danach Start.bat im entpackten Ordner starten.
echo Please unzip first: right-click the zip file, then "Extract All". Then run Start.bat from that folder.
pause
exit /b 1

:no_python
echo Programm\python fehlt. Bitte die Zip-Datei neu entpacken (Rechtsklick, dann "Alle extrahieren").
echo Programm\python is missing. Please unzip the zip file again (right-click, then "Extract All").
pause
exit /b 1
