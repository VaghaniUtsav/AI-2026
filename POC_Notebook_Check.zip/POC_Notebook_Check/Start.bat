@echo off
setlocal
rem No "cd" into this folder: cmd.exe cannot do that on a network path (\\server\share), so use full paths.
title Inventaris-Formular POC
if not exist "%~dp0App\Program\send_reminders.py" goto not_unzipped
call :find_python
if not defined PY goto no_python

echo ==============================================================
echo  Inventaris-Formular - Erinnerungen / reminders (Proof of Concept)
echo ==============================================================
echo.
echo Vergleicht "MySEG All Employee List" mit "MySEG Inventaris Form List".
echo Wer das Formular noch nicht ausgefuellt hat, bekommt eine Erinnerung.
echo Compares the two lists in "Data"; everyone without a form gets a reminder.
echo --------------------------------------------------------------
%PY% "%~dp0App\Program\send_reminders.py"
if errorlevel 1 goto error
echo.
echo Fertig. / Done.
pause
exit /b 0

:error
echo.
echo FEHLER / ERROR - siehe Meldung oben / see the message above.
pause
exit /b 1

:not_unzipped
echo Bitte zuerst die Zip-Datei entpacken: Rechtsklick auf die Zip-Datei, dann "Alle extrahieren".
echo Danach Start.bat im entpackten Ordner starten.
echo Please unzip first: right-click the zip file, then "Extract All". Then run Start.bat from that folder.
pause
exit /b 1

:no_python
echo Python wurde nicht gefunden. Bitte zuerst Setup.bat doppelklicken (einmal pro PC).
echo Python was not found. Please double-click Setup.bat first (once per PC).
pause
exit /b 1

:find_python
rem the Python launcher "py", else where Setup.bat installs Python (PATH may not know it yet)
set "PY="
py --version >nul 2>&1 && set "PY=py" && exit /b 0
if exist "%LOCALAPPDATA%\Programs\Python\Python314\python.exe" set PY="%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
exit /b 0
