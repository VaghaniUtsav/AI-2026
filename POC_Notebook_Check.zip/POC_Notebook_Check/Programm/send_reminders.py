r"""Remind everyone on the employee list who has not filled out the Inventaris form, through Knox Portal Mail (POC).

Usage (inside the POC folder; Start.bat does this for you):
    python Programm\send_reminders.py
    python Programm\send_reminders.py --employees "D:\other\All.xlsx" --forms "D:\other\Forms.xlsx"

Both lists are Excel files with the columns Name and E-Mail; people are matched by email (case does not matter).
Test mode ([Versand] testmodus = ja in Email_Texte.ini, the default) sends every reminder to the test address.
Real mode sends to the real addresses - never to demo addresses (example.com etc.).
Nothing is sent before you type JA. The Knox API key is read from the KNOX_API_KEY environment variable.
Design: docs/superpowers/specs/2026-10-27-hr-poc-reminders-design.md
"""
import argparse
import configparser
import csv
import hashlib
import html
import os
import re
import sys
import unicodedata
from collections import Counter, namedtuple
from datetime import date, datetime
from pathlib import Path

try:
    import openpyxl
except ImportError:
    sys.exit("openpyxl fehlt – bitte Setup.bat ausführen / openpyxl missing – run Setup.bat")

EMPLOYEE_FILE = "MySEG All Employee List.xlsx"
FORM_FILE = "MySEG Inventaris Form List.xlsx"
LIST_COLUMNS = {"name": "Name", "email": "E-Mail"}  # both lists
SUBJECT_MARKER = "[POC]"
SEPARATOR = "\n\n" + "-" * 60 + "\n\n"
LANGUAGES = ("Deutsch", "English")
DEMO_DOMAINS = ("example.com", "example.org", "example.net")
DEMO_TLDS = ("example", "test", "invalid", "localhost")
LOG_FIELDS = ("sent_at", "to", "meant_for", "name", "subject", "fingerprint")
LOG_LOCKED = ("Versandprotokoll ist gesperrt (in Excel offen?) – nichts gesendet / "
              "send log is locked (open in Excel?) – nothing sent")
LOG_UNREADABLE = ('Versandprotokoll nicht lesbar (von Excel gespeichert?) – "heute schon gesendet" wird nicht '
                  'erkannt / send log unreadable (saved by Excel?) – "already sent today" cannot be detected')
# The Knox Portal Mail flow, copied from HR Auto Email (hr_auto_reply/hr_config.py)
KNOX_URL = "https://agent.sec.samsung.net/api/v1/run/a16cce0c-d4aa-464d-924f-7dc39b884001?stream=false"
KNOX_COMPONENT = "knox_portal_mail-MRExY"
KNOX_KEY_ENV = "KNOX_API_KEY"
KNOX_SUBJECT_MAX_BYTES = 300  # Knox rejects longer titles

Reminder = namedtuple("Reminder", "to subject body name meant_for")  # to: where it goes; meant_for: whose it is


def repair_text(text):
    """Undo UTF-8 read as cp1252 ('GebÃ¤ude' -> 'Gebäude'). Text that isn't mojibake comes back unchanged."""
    try:
        return text.encode("cp1252").decode("utf-8")
    except UnicodeError:
        return text


def clean(value):
    """Cell value -> stripped, repaired text ('' for an empty cell), without invisible characters (zero-width, BOM)."""
    if value is None:
        return ""
    text = repair_text(str(value).strip())  # repair first: mojibake can itself contain a soft hyphen
    return "".join(c for c in text if unicodedata.category(c) != "Cf").strip()


def _header_key(header):
    """'  E-Mail: ' -> 'e-mail', so small header differences don't matter."""
    return " ".join(str(header or "").split()).rstrip(":").strip().lower()


def read_rows(path, columns):
    """Read the first sheet of an .xlsx file. columns maps key -> header text.

    Returns one dict {key: cell value} per row, skipping rows where all those columns are empty.
    """
    path = Path(path)
    if not path.is_file():
        sys.exit(f"File not found: {path}")
    try:
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    except Exception as e:  # .xls, corrupt or unreadable file: one clear line instead of a traceback
        sys.exit(f"Cannot open {path}: {e}")
    try:
        rows = wb.worksheets[0].iter_rows(values_only=True)
        headers = list(next(rows, ()))
        keys = [_header_key(h) for h in headers]
        index = {}
        for key, title in columns.items():
            if _header_key(title) not in keys:
                found = ", ".join(repr(h) for h in headers if h is not None)
                sys.exit(f"Column {title!r} not found in {path.name}. Columns found: {found}")
            index[key] = keys.index(_header_key(title))
        result = []
        for row in rows:
            record = {key: row[i] if i < len(row) else None for key, i in index.items()}
            if any(clean(value) for value in record.values()):
                result.append(record)
        return result
    except Exception as e:  # read-only mode parses the sheet lazily, so damaged sheet XML fails here
        sys.exit(f"Cannot open {path}: {e}")
    finally:
        wb.close()  # read-only workbooks keep the file open until closed


def is_demo_address(address):
    """Reserved example/test addresses (example.com/.org/.net, *.test, ...) - never sent to."""
    domain = address.strip().lower().rpartition("@")[2]
    return (domain in DEMO_DOMAINS or domain.endswith(tuple("." + d for d in DEMO_DOMAINS))
            or domain.rpartition(".")[2] in DEMO_TLDS)


def greeting_name(name, email):
    """'Jonas Weber/Sales/SEG (Extern)' -> 'Jonas Weber'. Without a name, greet with the address."""
    return " ".join(re.sub(r"\(.*?\)", " ", name.split("/")[0]).split()) or email


def load_texts(path):
    """Read Email_Texte.ini -> {'subject', 'form_link', 'test_mode', 'test_address', 'Deutsch': {...}, 'English': {...}}."""
    path = Path(path)
    if not path.is_file():
        sys.exit(f"Textdatei nicht gefunden / texts file not found: {path}")
    try:
        raw = path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:  # saved by an older Notepad as 'ANSI'
        raw = path.read_text(encoding="cp1252")
    parser = configparser.ConfigParser(interpolation=None)
    try:
        parser.read_string(raw)
    except configparser.Error as e:
        sys.exit(f"{path.name} ist fehlerhaft / is broken: {e}")
    needed = [("Allgemein", "betreff"), ("Allgemein", "formular_link"), ("Versand", "testmodus"),
              ("Versand", "testadresse")] + [(lang, "text") for lang in LANGUAGES]
    for section, key in needed:
        if not parser.has_option(section, key):
            sys.exit(f"In {path.name} fehlt / is missing: [{section}] {key}")
    test_mode = parser["Versand"]["testmodus"].strip().lower()
    if test_mode not in ("ja", "nein"):
        sys.exit(f"In {path.name}: [Versand] testmodus muss ja oder nein sein / must be ja or nein: {test_mode!r}")
    test_address = parser["Versand"]["testadresse"].strip()
    if "@" not in test_address:
        sys.exit(f"In {path.name}: [Versand] testadresse ist keine E-Mail-Adresse / is not an email address: "
                 f"{test_address!r}")
    return {"subject": parser["Allgemein"]["betreff"], "form_link": parser["Allgemein"]["formular_link"],
            "test_mode": test_mode == "ja", "test_address": test_address,
            **{lang: dict(parser[lang]) for lang in LANGUAGES}}


def _body(name, texts):
    """German block, separator, English block. Plain replace: stray braces typed by HR cannot break it."""
    return SEPARATOR.join(texts[lang]["text"].replace("{name}", name).replace("{form_link}", texts["form_link"])
                          for lang in LANGUAGES)


def build_reminders(employees, forms, texts):
    """Rows of both lists -> (one Reminder per employee address not on the form list, names without an address)."""
    filled = {clean(row["email"]).lower() for row in forms}
    people, no_email = {}, []  # email -> greeting name
    for row in employees:
        email, name = clean(row["email"]).lower(), clean(row["name"])
        if not email:
            no_email.append(name)
        elif email not in filled and email not in people:
            people[email] = greeting_name(name, email)
    subject = SUBJECT_MARKER + " " + texts["subject"]
    return [Reminder(email, subject, _body(name, texts), name, email) for email, name in people.items()], no_email


def plan_mails(reminders, texts, already_sent):
    """Test mode: every mail to the test address. Real mode: no demo addresses. Both: not the same mail twice a day.

    already_sent holds the fingerprints of today's send log. Returns (mails to send, Counter 'demo'/'today').
    """
    mails, held = [], Counter()
    for mail in reminders:
        if texts["test_mode"]:
            mail = mail._replace(to=texts["test_address"], subject=f"[TEST: {mail.meant_for}] {mail.subject}")
        elif is_demo_address(mail.to):
            held["demo"] += 1
            continue
        if fingerprint(mail) in already_sent:
            held["today"] += 1
            continue
        mails.append(mail)
    return mails, held


def fingerprint(mail):
    """What 'the same mail' means for the send log: same address, subject and body."""
    return hashlib.sha256("\n".join((mail.to, mail.subject, mail.body)).encode("utf-8")).hexdigest()[:16]


def _log_delimiter(path):
    """',' as this program writes the log, ';' once German Excel has saved it again."""
    with open(path, encoding="utf-8-sig", errors="replace") as f:
        return ";" if ";" in f.readline() else ","


def sent_today(path, today):
    """Fingerprints of the mails the send log lists for today; says so if the log cannot be read."""
    if not path.is_file():
        return set()
    try:
        delimiter = _log_delimiter(path)
        with open(path, newline="", encoding="utf-8-sig", errors="replace") as f:
            reader = csv.DictReader(f, delimiter=delimiter)
            if reader.fieldnames and "fingerprint" not in reader.fieldnames:
                print(LOG_UNREADABLE)
                return set()
            return {row.get("fingerprint") for row in reader if (row.get("sent_at") or "").startswith(today.isoformat())}
    except OSError:
        sys.exit(LOG_LOCKED)


def append_log(path, mail, sent_at):
    """Add one sent mail to the send log. A new log starts with a BOM and the header, so Excel shows umlauts."""
    is_new = not path.exists() or path.stat().st_size == 0
    delimiter = "," if is_new else _log_delimiter(path)  # keep Excel's ';' if it saved the log again
    with open(path, "a", newline="", encoding="utf-8-sig" if is_new else "utf-8") as f:
        writer = csv.writer(f, delimiter=delimiter)
        if is_new:
            writer.writerow(LOG_FIELDS)
        writer.writerow([sent_at.isoformat(timespec="seconds"), mail.to, mail.meant_for, mail.name, mail.subject,
                         fingerprint(mail)])


def knox_sender(api_key, post=None):
    """send(mail) through the Knox Portal Mail flow - the same call as HR Auto Email's KnoxMailSender.

    post replaces requests.post in tests. Raises RuntimeError when Knox does not answer 200.
    """
    if post is None:
        try:
            import requests
        except ImportError:
            sys.exit("requests fehlt – bitte Setup.bat ausführen / requests missing – run Setup.bat")
        post = requests.post

    def send(mail):
        content = ('<html><body style="font-family: Arial, sans-serif; font-size: 14px; color: #333333; '
                   'line-height: 1.6;">' + html.escape(mail.body, quote=False).replace("\n", "<br>\n")
                   + "</body></html>")
        title = mail.subject.encode("utf-8")[:KNOX_SUBJECT_MAX_BYTES].decode("utf-8", errors="ignore")
        response = post(KNOX_URL, timeout=60,
                        headers={"Content-Type": "application/json", "x-api-key": api_key},
                        json={"input_type": "text", "output_type": "text", "input_value": "hello world!",
                              "component_inputs": {KNOX_COMPONENT: {"content": content, "target_emails": mail.to,
                                                                    "title": title}}})
        if response.status_code != 200:
            raise RuntimeError(f"Knox HTTP {response.status_code}: {response.text[:300]}")

    return send


def _who(mail):
    """'address', or in test mode 'test address (für / for real address)'."""
    return mail.to if mail.to == mail.meant_for else f"{mail.to} (für / for {mail.meant_for})"


def check_writable(path):
    """Stop before the JA question if the send log cannot be written (e.g. open in Excel)."""
    try:
        if path.exists():
            with open(path, "a", encoding="utf-8"):
                pass
    except OSError:
        sys.exit(LOG_LOCKED)


def send_mails(mails, send, log_path, ask=input):
    """Send once the user types JA; log each sent mail at once. Returns (sent, failed)."""
    if ask("Zum Senden JA eingeben / type JA to send: ").strip().upper() != "JA":
        print("Nichts gesendet / Nothing sent")
        return 0, 0
    sent = failed = 0
    for mail in mails:
        try:
            send(mail)
        except Exception as e:  # Knox refused it or the network failed: report it, carry on
            failed += 1
            print(f"Fehler beim Senden an / failed to send to {_who(mail)}: {e}")
            continue
        sent += 1
        try:
            append_log(log_path, mail, datetime.now())
        except OSError as e:  # sent but not logged: the next run would send it again
            sys.exit(f"An {_who(mail)} gesendet, aber nicht protokolliert – Lauf gestoppt / "
                     f"sent to {_who(mail)} but not logged – run stopped: {e}")
    return sent, failed


def main(argv=None, send=None, ask=input):
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Remind everyone who has not filled out the Inventaris form (POC).")
    parser.add_argument("--employees", type=Path, default=here.parent / "Daten" / EMPLOYEE_FILE, help="all employees")
    parser.add_argument("--forms", type=Path, default=here.parent / "Daten" / FORM_FILE, help="who filled out the form")
    parser.add_argument("--texts", type=Path, default=here / "Email_Texte.ini", help="email texts and settings")
    parser.add_argument("--log-folder", type=Path, default=here.parent / "Berichte", help="folder for the send log")
    args = parser.parse_args(argv)

    texts = load_texts(args.texts)
    employees, forms = read_rows(args.employees, LIST_COLUMNS), read_rows(args.forms, LIST_COLUMNS)
    reminders, no_email = build_reminders(employees, forms, texts)
    log_path = args.log_folder / ("Versandprotokoll_Test.csv" if texts["test_mode"] else "Versandprotokoll.csv")
    mails, held = plan_mails(reminders, texts, sent_today(log_path, date.today()))
    held_text = (f"Demo übersprungen / demo skipped: {held['demo']}   "
                 f"heute schon gesendet / already sent today: {held['today']}")
    print(f"Mitarbeiterliste / employee list: {len(employees)}   Formularliste / form list: {len(forms)}")
    for name in no_email:
        print(f"  ohne E-Mail, keine Erinnerung / no email, no reminder: {name or '(ohne Namen / no name)'}")
    if texts["test_mode"]:
        print(f"TESTMODUS / TEST MODE: alle Mails gehen an / every mail goes to {texts['test_address']}")
    else:
        print("ECHTER VERSAND / REAL MODE: Mails gehen an die echten Adressen / mails go to the real addresses")
    if not mails:
        print(f"Nichts zu senden / nothing to send   {held_text}")
        return 0
    print(f"{len(mails)} Mail(s) werden gesendet / will be sent:")
    for mail in mails:
        print(f"    {_who(mail)}")
    if send is None:
        api_key = os.environ.get(KNOX_KEY_ENV)
        if not api_key:
            sys.exit(f"{KNOX_KEY_ENV} fehlt – einmal ausführen: setx {KNOX_KEY_ENV} \"<Schlüssel>\", dann ein neues "
                     f"Fenster öffnen / {KNOX_KEY_ENV} is not set – run once: setx {KNOX_KEY_ENV} \"<key>\", "
                     "then open a new window")
        send = knox_sender(api_key)
    check_writable(log_path)
    sent, failed = send_mails(mails, send, log_path, ask)
    print(f"Gesendet / sent: {sent}   Fehler / failed: {failed}   {held_text}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
