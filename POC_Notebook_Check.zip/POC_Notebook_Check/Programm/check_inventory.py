"""Check the notebook IDs employees entered in MySEG against the inventory list.

Usage (on the company laptop):
    pip install openpyxl
    python check_inventory.py
    python check_inventory.py --myseg "D:\\other\\MySEG.xlsx" --inventory "D:\\other\\NB.xlsx" --out "D:\\reports"
    python check_inventory.py --directory "D:\\other\\Mitarbeiterverzeichnis.xlsx" --open

Writes Pruefbericht_<date>.xlsx (one row per problem) next to the MySEG file and prints a summary.
Design: docs/superpowers/specs/2026-10-20-notebook-id-check-design.md
"""
import argparse
import os
import re
import sys
import unicodedata
from collections import Counter, defaultdict, namedtuple
from datetime import date
from pathlib import Path

try:
    import openpyxl
    from openpyxl.styles import Font
except ImportError:
    sys.exit("openpyxl is not installed. Run: pip install openpyxl")

ISSUE_ORDER = ["Blank", "Invalid format", "Not in inventory", "Duplicate ID", "Owner mismatch", "Not submitted"]
MYSEG_COLUMNS = {"email": "E-Mail:", "name": "Name:", "id": "Notebook ID:"}
INVENTORY_COLUMNS = {"id": "Inventarnummer systematisch", "last": "Benutzer, Nachname", "first": "Benutzer, Vorname"}
DIRECTORY_COLUMNS = {"name": "Name", "email": "E-Mail"}
DEFAULT_DIR = Path(r"K:\My files\Inventory Automation")
REPORT_COLUMNS = ["Issue", "E-Mail", "Name", "Notebook ID", "Details"]

Issue = namedtuple("Issue", "issue email name notebook_id details")


def repair_text(text):
    """Undo UTF-8 read as cp1252 ('GebÃ¤ude' -> 'Gebäude'). Text that isn't mojibake comes back unchanged."""
    try:
        return text.encode("cp1252").decode("utf-8")
    except UnicodeError:
        return text


def clean(value):
    """Cell value -> stripped, repaired text ('' for an empty cell), without invisible characters (zero-width, BOM)."""
    if value is None:
        return ""
    text = repair_text(str(value).strip())  # repair first: mojibake can itself contain a soft hyphen
    return "".join(c for c in text if unicodedata.category(c) != "Cf").strip()


def normalize_id(value):
    """Cell value -> ID text: 119638, 119638.0 and ' 119638 ' all give '119638'; empty cell gives ''."""
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    return clean(value)


def is_valid_id(notebook_id):
    """Exactly six ASCII digits."""
    return re.fullmatch(r"[0-9]{6}", notebook_id) is not None


_FOLD = str.maketrans({"ä": "ae", "ö": "oe", "ü": "ue", "ß": "ss"})


def name_words(value):
    """Name cell -> set of comparable words: 'Probe, Anna-Lena' -> {'probe', 'anna', 'lena'}.

    Ignores the display-name suffix ('Max Muster/Department/Company') and notes in parentheses.
    """
    text = re.sub(r"\(.*?\)", " ", clean(value).split("/")[0])
    text = unicodedata.normalize("NFC", text).lower().translate(_FOLD)
    text = "".join(c for c in unicodedata.normalize("NFKD", text) if not unicodedata.combining(c))
    return frozenset(re.findall(r"[^\W\d_]+", text))


def names_match(a, b):
    """Word sets match if one contains the other, so word order and middle names don't matter."""
    # ponytail: subset rule, a lone first name matches every owner with that first name; add an alias list if noisy
    return bool(a) and bool(b) and (a <= b or b <= a)


def is_ownerless(first_words, last_words):
    """Inventory row assigned to Pool / NN / nobody."""
    return last_words == {"pool"} or first_words == {"nn"} or not (first_words or last_words)


def find_issues(myseg_rows, inventory_rows):
    """Compare MySEG entries with inventory. Rows are dicts from read_rows(). Returns Issues sorted for the report."""
    inventory = {}  # notebook ID -> (owner display name, owner words, ownerless)
    for row in inventory_rows:
        notebook_id = normalize_id(row["id"])
        if is_valid_id(notebook_id):
            first, last = clean(row["first"]), clean(row["last"])
            first_words, last_words = name_words(first), name_words(last)
            ownerless = is_ownerless(first_words, last_words)
            inventory[notebook_id] = (f"{first} {last}".strip(), first_words | last_words, ownerless)

    entries, seen = [], set()  # one entry per (person, ID): resubmissions are reported once
    for row in myseg_rows:
        email, name, notebook_id = clean(row["email"]), clean(row["name"]), normalize_id(row["id"])
        person = email.lower() or " ".join(sorted(name_words(name)))
        if (person, notebook_id) not in seen:
            seen.add((person, notebook_id))
            entries.append((person, email, name, notebook_id))

    has_valid_id = {person for person, _, _, notebook_id in entries if is_valid_id(notebook_id)}
    issues = []
    for person, email, name, notebook_id in entries:
        if not is_valid_id(notebook_id) and person in has_valid_id:
            continue  # earlier attempt, superseded: the same person also entered a valid ID
        if not notebook_id:
            issues.append(Issue("Blank", email, name, "", ""))
        elif not is_valid_id(notebook_id):
            issues.append(Issue("Invalid format", email, name, notebook_id, "not 6 digits"))
        elif notebook_id not in inventory:
            issues.append(Issue("Not in inventory", email, name, notebook_id, ""))
        else:
            owner, owner_words, ownerless = inventory[notebook_id]
            if ownerless:
                issues.append(Issue("Owner mismatch", email, name, notebook_id, "inventory shows no owner (Pool/NN)"))
            elif not names_match(name_words(name), owner_words):
                issues.append(Issue("Owner mismatch", email, name, notebook_id, f"inventory owner: {owner}"))

    by_id = defaultdict(list)
    for person, email, name, notebook_id in entries:
        if is_valid_id(notebook_id):
            by_id[notebook_id].append((person, email, name))
    for notebook_id, group in by_id.items():
        if len(group) > 1:  # entries are unique per (person, ID), so these are different people
            for person, email, name in group:
                others = ", ".join(e or n for p, e, n in group if p != person)
                issues.append(Issue("Duplicate ID", email, name, notebook_id, "also entered by: " + others))

    entered_ids = {entry[3] for entry in entries}
    myseg_names = [name_words(entry[2]) for entry in entries]
    for notebook_id, (owner, owner_words, ownerless) in inventory.items():
        if ownerless or notebook_id in entered_ids:
            continue
        if not any(names_match(owner_words, words) for words in myseg_names):
            issues.append(Issue("Not submitted", "", owner, notebook_id, "in inventory, no MySEG entry"))

    issues.sort(key=lambda i: (ISSUE_ORDER.index(i.issue), i.name.lower(), i.notebook_id))
    return issues


def add_directory_emails(issues, directory_rows):
    """Fill in the email of 'Not submitted' rows from an employee directory (name -> email).

    Only an exact name match counts (same word set): a wrong match would email the wrong person.
    """
    directory = defaultdict(set)  # name word set -> emails
    for row in directory_rows:
        words, email = name_words(row["name"]), clean(row["email"]).lower()
        if words and email:
            directory[words].add(email)
    result = []
    for issue in issues:
        if issue.issue == "Not submitted":
            emails = directory.get(name_words(issue.name), set())
            if len(emails) == 1:
                issue = issue._replace(email=next(iter(emails)), details=issue.details + "; email from directory")
            elif emails:
                issue = issue._replace(details=issue.details + "; several possible emails in directory")
            else:
                issue = issue._replace(details=issue.details + "; no email found in directory")
        result.append(issue)
    return result


def _header_key(header):
    """'  Notebook ID: ' -> 'notebook id', so small header differences don't matter."""
    return " ".join(str(header or "").split()).rstrip(":").strip().lower()


def read_rows(path, columns):
    """Read the first sheet of an .xlsx file. columns maps key -> header text.

    Returns one dict {key: cell value} per row, skipping rows where all those columns are empty.
    """
    path = Path(path)
    if not path.is_file():
        sys.exit(f"File not found: {path}")
    try:
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    except Exception as e:  # .xls, corrupt or unreadable file: one clear line instead of a traceback
        sys.exit(f"Cannot open {path}: {e}")
    try:
        rows = wb.worksheets[0].iter_rows(values_only=True)
        headers = list(next(rows, ()))
        keys = [_header_key(h) for h in headers]
        index = {}
        for key, title in columns.items():
            if _header_key(title) not in keys:
                found = ", ".join(repr(h) for h in headers if h is not None)
                sys.exit(f"Column {title!r} not found in {path.name}. Columns found: {found}")
            index[key] = keys.index(_header_key(title))
        result = []
        for row in rows:
            record = {key: row[i] if i < len(row) else None for key, i in index.items()}
            if any(clean(value) for value in record.values()):
                result.append(record)
        return result
    except Exception as e:  # read-only mode parses the sheet lazily, so damaged sheet XML fails here
        sys.exit(f"Cannot open {path}: {e}")
    finally:
        wb.close()  # read-only workbooks keep the file open until closed


def write_report(issues, path):
    """Write the issues to an .xlsx: bold frozen header, filter, employee text kept as text."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Issues"
    ws.append(REPORT_COLUMNS)
    for issue in issues:
        ws.append(list(issue))
        for cell in ws[ws.max_row]:
            if cell.data_type == "f":  # employee typed text starting with '=': show it, never run it
                cell.data_type = "s"
    for cell in ws[1]:
        cell.font = Font(bold=True)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for letter, width in zip("ABCDE", (18, 32, 28, 14, 45)):
        ws.column_dimensions[letter].width = width
    try:
        wb.save(path)
    except PermissionError:
        sys.exit(f"Cannot write {path}. Is it open in Excel? Close it and run again.")
    except OSError as e:
        sys.exit(f"Cannot write {path}: {e}")


def main(argv=None):
    parser = argparse.ArgumentParser(description="Check MySEG notebook IDs against the inventory list.")
    parser.add_argument("--myseg", type=Path, default=DEFAULT_DIR / "MySEG Meldungen.xlsx")
    parser.add_argument("--inventory", type=Path, default=DEFAULT_DIR / "gesamte NB-Liste.xlsx")
    parser.add_argument("--out", type=Path, help="folder for the report (default: folder of the MySEG file)")
    parser.add_argument("--directory", type=Path, help="employee directory (Name, E-Mail) for 'Not submitted' emails")
    parser.add_argument("--open", action="store_true", help="open the report when it is written")
    args = parser.parse_args(argv)

    myseg_rows = read_rows(args.myseg, MYSEG_COLUMNS)
    inventory_rows = read_rows(args.inventory, INVENTORY_COLUMNS)
    directory_rows = read_rows(args.directory, DIRECTORY_COLUMNS) if args.directory else None
    issues = find_issues(myseg_rows, inventory_rows)
    if directory_rows is not None:
        issues = add_directory_emails(issues, directory_rows)
    skipped = sum(not is_valid_id(normalize_id(row["id"])) for row in inventory_rows)
    report = (args.out or args.myseg.parent) / f"Pruefbericht_{date.today():%Y-%m-%d}.xlsx"
    write_report(issues, report)

    print(f"MySEG rows read:     {len(myseg_rows)}")
    print(f"Inventory rows read: {len(inventory_rows)}")
    if skipped:
        print(f"Warning: {skipped} inventory rows skipped (ID not 6 digits)")
    counts = Counter(issue.issue for issue in issues)
    for kind in ISSUE_ORDER:
        print(f"  {kind:<17} {counts[kind]}")
    if directory_rows is not None:
        found = sum(1 for issue in issues if issue.issue == "Not submitted" and issue.email)
        print(f"Directory: {found} of {counts['Not submitted']} 'Not submitted' rows got an email")
    print(f"Report: {report}")
    if args.open and hasattr(os, "startfile"):
        os.startfile(report)  # Windows: opens the report in Excel
    return 0


if __name__ == "__main__":
    sys.exit(main())
