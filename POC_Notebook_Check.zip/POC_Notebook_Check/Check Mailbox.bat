@echo off
setlocal
rem No "cd" into this folder: cmd.exe cannot do that on a network path (\\server\share), so use full paths.
title Inventaris-Formular POC - Postfach / Mailbox
if not exist "%~dp0App\Program\Notebook_Check.exe" goto not_unzipped

echo ==============================================================
echo  Inventaris-Formular - Postfach pruefen / check the mailbox
echo ==============================================================
echo  1. Liest die zwei Outlook-Ordner / reads the two Outlook folders
echo  2. Zeigt jede gefundene Adresse / shows every address it found
echo  3. Eingetragen wird erst nach JA / nothing is added before you type YES
"%~dp0App\Program\Notebook_Check.exe" --check-mailbox
if errorlevel 1 goto error
echo.
echo Fertig. / Done.
pause
exit /b 0

:error
echo.
echo FEHLER / ERROR - siehe Meldung oben / see the message above.
pause
exit /b 1

:not_unzipped
echo Bitte zuerst die Zip-Datei entpacken: Rechtsklick auf die Zip-Datei, dann "Alle extrahieren".
echo Danach Start.bat im entpackten Ordner starten.
echo Please unzip first: right-click the zip file, then "Extract All". Then run Start.bat from that folder.
pause
exit /b 1
