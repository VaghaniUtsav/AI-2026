"""Keeps the SEG AI Data Guide in step with the rules page (.scratch/rules-page-sync/spec.md, ADR 0004).

    python -I update_guide.py             fetch the rules page, update the guide's data, check it, then offer to publish
    python -I update_guide.py --selftest  prove every update case on made-up rules pages, in a temporary folder
"""
import contextlib
import getpass
import importlib.util
import io
import json
import os
import re
import shutil
import sys
import tempfile
import urllib.error
import urllib.request
from datetime import date, datetime
from html import escape
from pathlib import Path

ROOT = Path(__file__).resolve().parent
GUIDE_NAME = "seg-ai-data-guide.html"
# python -I leaves this folder off sys.path, so check_guide.py is loaded from its path. It stays unchanged (spec, decision 10).
_spec = importlib.util.spec_from_file_location("check_guide", ROOT / "check_guide.py")
cg = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(cg)
CLUSTER_OF, RESULT_OF, RULES_URL = cg.CLUSTER_OF, cg.RESULT_OF, cg.RULES_URL
block, check, parse_rules, src_of = cg.block, cg.check, cg.parse_rules, cg.src_of

# The data points' lines inside the data block; the rest of the file is never rewritten (spec, "Editing the data block in place").
POINTS = re.compile(r'\n  "dataPoints": \[\n(.*?)\n  \]\n\}\n</script>', re.S)
PWC = "permitted_with_conditions"
ANONYMISED = "Nur anonymisiert / Only if anonymized"
# The guide's own opening for "only anonymised" conditions; {link} renders as links.prepGuide.
ANONYMISED_CONDITION = {"de": "Nur anonymisiert, wie im {link} beschrieben.",
                        "en": "Only anonymised, as described in the {link}."}
# Where a new data point goes under a topic with more than one data cluster; CLUSTER_OF's sets have no order.
DEFAULT_CLUSTER = {"Allgemeine Unternehmensinfos / General company information": "hq_basic"}
AS_OF = re.compile(r'("meta": \{[^}]*"asOf": ")\d{4}-\d{2}-\d{2}(")')
WORDING_REQUEST = """# Wording request: data points with the rules page's wording

These data points in the SEG AI Data Guide still use the rules page's own wording. Write the guide's own
wording for each one and save your answer as `source/wording.json`. The next `python -I update_guide.py`
applies it.

Style rules:
- Names and conditions are written for employees, in German and English.
- German uses "du".
- Never copy the page's text: say what it means for someone about to put data into an AI tool.
- "Only anonymised" conditions say "wie im {link} beschrieben" / "as described in the {link}".
- Keywords are lists of search words, in both languages.
- Give a condition exactly when the data point's verdict is permitted_with_conditions.

Answer format, JSON keyed by Nr:

    {"111": {"name": {"de": "…", "en": "…"},
             "condition": {"de": "…", "en": "…"},
             "keywords": {"de": ["…"], "en": ["…"]}}}
"""


def read_guide(path):
    """(the file's text with \\n line ends, its own line end), so that writing it back changes no other line."""
    text = path.read_bytes().decode("utf-8")
    newline = "\r\n" if "\r\n" in text else "\n"
    return text.replace("\r\n", "\n"), newline


def dumps(value):
    return json.dumps(value, ensure_ascii=False)


def render(dp):
    """A data point's lines in the data block, in the format all of them use: row, cluster, verdict and src
    (and pageWording) on the first line, then name, condition if it has one, and keywords."""
    flag = ', "pageWording": true' if dp.get("pageWording") else ""
    lines = [f'    {{ "row": {dp["row"]}, "cluster": {dumps(dp["cluster"])}, "verdict": {dumps(dp["verdict"])},'
             f' "src": {dumps(dp["src"])}{flag},',
             f'      "name": {dumps(dp["name"])},']
    if "condition" in dp:
        lines.append(f'      "condition": {dumps(dp["condition"])},')
    lines.append(f'      "keywords": {dumps(dp["keywords"])} }}')
    return "\n".join(lines)


def with_points(html, points):
    """html with its data points rendered from points; everything else stays byte for byte."""
    found = POINTS.search(html)
    if not found:
        sys.exit(f"{GUIDE_NAME}: the data block's dataPoints list isn't laid out as update_guide.py expects")
    return html[:found.start(1)] + ",\n".join(render(dp) for dp in points) + html[found.end(1):]


def default_cluster(topic):
    """The data cluster for a new data point under topic, or for one whose topic no longer allows its cluster."""
    if topic in DEFAULT_CLUSTER:
        return DEFAULT_CLUSTER[topic]
    if len(CLUSTER_OF[topic]) != 1:
        sys.exit(f"topic {topic!r} has several data clusters and none is the default;"
                 " add it to DEFAULT_CLUSTER in update_guide.py")
    return next(iter(CLUSTER_OF[topic]))


def page_wording(dp, row, verdict):
    """Gives dp the rules page's own name and condition, flagged as page wording until someone polishes it."""
    dp["name"] = {"de": row["de"], "en": row["en"]}
    dp.pop("condition", None)
    if verdict == PWC and row["result"] == ANONYMISED:
        dp["condition"] = {lang: f"{text} {row['condition']}".strip() for lang, text in ANONYMISED_CONDITION.items()}
    elif verdict == PWC:
        dp["condition"] = {"de": row["condition"], "en": row["condition"]}
    dp["pageWording"] = True


def update(points, rows):
    """Brings points (the guide's data points; changed in place) in step with rows (the rules page, {Nr: row}), as
    the spec's table says. Returns the changes, {group: ["Nr N: old → new"]}; stops on a topic or result it doesn't know."""
    for nr, r in sorted(rows.items()):
        if r["topic"] not in CLUSTER_OF:
            sys.exit(f"Nr {nr}: unknown topic {r['topic']!r} on the rules page; add it to CLUSTER_OF in check_guide.py"
                     " (a code change, made on the build laptop); nothing changed")
        if r["result"] not in RESULT_OF:
            sys.exit(f"Nr {nr}: unknown result {r['result']!r} on the rules page; add it to RESULT_OF in check_guide.py"
                     " (a code change, made on the build laptop); nothing changed")
    published = {nr: r for nr, r in rows.items() if RESULT_OF[r["result"]]}
    changes = {"removed": [], "new": [], "verdict changed": [], "reworded": [], "moved": []}
    for dp in list(points):
        nr, r = dp["row"], published.get(dp["row"])
        if r is None:
            points.remove(dp)
            why = rows[nr]["result"] if nr in rows else "not on the rules page"
            changes["removed"].append(f"Nr {nr}: {dp['name']['en']} → removed ({why})")
            continue
        verdict = RESULT_OF[r["result"]]
        if dp["src"] != src_of(r):
            result_only = any(src_of({**r, "result": old}) == dp["src"] for old in RESULT_OF)
            if result_only or dp["verdict"] != verdict:  # a rewording never hides a new verdict
                changes["verdict changed"].append(f"Nr {nr}: {dp['verdict']} → {verdict} ({r['result']})")
            if not result_only:
                condition = f" (condition: {r['condition']})" if r["condition"] else ""
                changes["reworded"].append(f"Nr {nr}: {dp['name']['en']} → {r['en']}{condition}")
            if not result_only or PWC in (dp["verdict"], verdict):
                page_wording(dp, r, verdict)
            dp.update(verdict=verdict, src=src_of(r))
        if dp["cluster"] not in CLUSTER_OF[r["topic"]]:
            cluster = default_cluster(r["topic"])
            changes["moved"].append(f"Nr {nr}: {dp['cluster']} → {cluster} ({r['topic']})")
            dp["cluster"] = cluster
    for nr in sorted(set(published) - {dp["row"] for dp in points}):
        r = published[nr]
        de, en = r["topic"].split(" / ", 1)
        dp = {"row": nr, "cluster": default_cluster(r["topic"]), "verdict": RESULT_OF[r["result"]], "src": src_of(r),
              "keywords": {"de": [de], "en": [en]}}
        page_wording(dp, r, dp["verdict"])
        points.append(dp)
        changes["new"].append(f"Nr {nr}: → {r['en']} ({r['result']})")
    return changes


def fetch(token, saved):
    """The rules page's REST response: fetched with token and saved when it's a usable page, or without a token the
    saved copy. A login page or an error never replaces the saved copy."""
    if not token:
        if not saved.exists():
            sys.exit(f"no token and no saved rules page ({saved}); set CONFLUENCE_TOKEN or type the token when asked")
        return saved.read_bytes()
    request = urllib.request.Request(RULES_URL, headers={"Accept": "application/json"})
    request.add_unredirected_header("Authorization", f"Bearer {token}")  # never sent on to wherever a redirect points
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            data = response.read()
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            sys.exit("Confluence refused the token: create a new personal access token"
                     " (Confluence › Profile › Personal Access Tokens)")
        sys.exit(f"couldn't reach Confluence: HTTP {e.code} {e.reason}; nothing changed")
    except OSError as e:  # URLError, timeouts, proxy and certificate errors
        sys.exit(f"couldn't reach Confluence: {getattr(e, 'reason', e)}; nothing changed")
    try:
        parse_rules(data)
    except ValueError as e:
        sys.exit(f"Confluence sent no usable rules page ({e}); nothing changed")
    saved.parent.mkdir(parents=True, exist_ok=True)
    part = saved.with_name(saved.name + ".part")
    part.write_bytes(data)
    part.replace(saved)
    return data


def stamp():
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def plain_output():
    """Prints ? for what the output's code page can't show (→ on a cp1252 laptop, when a file or an agent takes the
    output) instead of stopping half-way through a run that has already written the guide. python -I ignores
    PYTHONIOENCODING and PYTHONUTF8, so this can't be set from outside."""
    sys.stdout.reconfigure(errors="replace")


def interactive():
    """Whether someone can answer a prompt. Windows calls NUL a tty too, which an agent or a script starting the
    run hands over as stdin, so there the console itself must say that stdin is one."""
    if not sys.stdin.isatty():
        return False
    if os.name != "nt":
        return True
    import ctypes
    import msvcrt
    mode = ctypes.c_uint32()
    return bool(ctypes.windll.kernel32.GetConsoleMode(msvcrt.get_osfhandle(sys.stdin.fileno()), ctypes.byref(mode)))


def request_wording(points, rows, path):
    """Writes source/wording-request.md for the data points with page wording, or removes it when there are none.
    Returns their Nrs."""
    flagged = [dp for dp in points if dp.get("pageWording")]
    if not flagged:
        path.unlink(missing_ok=True)
        return []
    parts = [WORDING_REQUEST]
    for dp in flagged:
        r = rows[dp["row"]]
        now = {key: dp[key] for key in ("verdict", "name", "condition", "keywords") if key in dp}
        parts.append(f"## Nr {dp['row']}\n\n"
                     f"- Rules page: {r['de']} / {r['en']}\n"
                     f"- Result: {r['result']}\n"
                     f"- Condition: {r['condition'] or '(none)'}\n"
                     f"- In the guide now: `{dumps(now)}`\n")
    path.write_text("\n".join(parts), encoding="utf-8")
    return [dp["row"] for dp in flagged]


def apply_wording(points, answer):
    """Puts polished wording from source/wording.json on the data points that still have page wording.
    Returns notes; stops, naming each Nr and what's wrong, when the answer isn't usable."""
    if not isinstance(answer, dict):
        sys.exit('source/wording.json: expected {"Nr": {"name": …, "condition": …, "keywords": …}}; nothing changed')
    errors, notes, ready = [], [], []
    both, _ = cg.texts(errors)
    by_row = {str(dp["row"]): dp for dp in points}
    for nr, w in answer.items():
        dp = by_row.get(nr)
        if not dp or not dp.get("pageWording"):
            notes.append(f"Nr {nr}: has no page wording in the guide, skipped")
            continue
        if not isinstance(w, dict):
            errors.append(f"Nr {nr}: needs name and keywords")
            continue
        both(w.get("name"), f"Nr {nr} name")
        both(w.get("keywords"), f"Nr {nr} keywords")
        keywords = w.get("keywords")
        if not (isinstance(keywords, dict) and all(isinstance(keywords.get(lang), list) for lang in cg.LANGS)):
            errors.append(f"Nr {nr} keywords: need a list of search words per language")
        if dp["verdict"] == PWC:
            both(w.get("condition"), f"Nr {nr} condition")
        elif "condition" in w:
            errors.append(f"Nr {nr}: only 'Permitted with conditions' carries a condition")
        ready.append((dp, w))
    if errors:
        sys.exit("source/wording.json: " + "; ".join(errors) + "; nothing changed")
    for dp, w in ready:
        dp.update({key: w[key] for key in ("name", "condition", "keywords") if key in w})
        del dp["pageWording"]
        notes.append(f"Nr {dp['row']}: polished wording applied")
    return notes


def run(root, token, today):
    """Steps 1 to 6 of the spec's update run, on the guide in root; today (YYYY-MM-DD) becomes meta.asOf if the
    guide changes. Stops with one message, having written nothing, when a step fails."""
    guide, source = root / GUIDE_NAME, root / "source"
    try:
        rows, version = parse_rules(fetch(token, source / "confluence.json"))
    except ValueError as e:
        sys.exit(f"rules page (source/confluence.json): {e}")
    print(f"rules page {version}: {len(rows)} rows")
    html, newline = read_guide(guide)
    data, problem = block(html)
    if problem:
        sys.exit(f"{GUIDE_NAME}: {problem}")
    points = data["dataPoints"]
    if with_points(html, points) != html:
        odd = [str(dp["row"]) for dp in points if render(dp) not in html]
        sys.exit(f"{GUIDE_NAME}: data points not in the data block's usual format (Nr {', '.join(odd) or '?'});"
                 " fix them by hand, then run it again")
    wording = source / "wording.json"
    notes = []
    if wording.exists():
        try:
            answer = json.loads(wording.read_bytes().decode("utf-8-sig"))
        except ValueError as e:
            sys.exit(f"source/wording.json isn't valid JSON: {e}; nothing changed")
        notes = apply_wording(points, answer)
    changes = update(points, rows)
    for group, lines in changes.items():  # before the check, so that a FAIL line follows the rows it comes from
        for line in lines:
            print(f"  {group}: {line}")
    new = with_points(html, points)
    if new != html:
        new = AS_OF.sub(lambda m: m.group(1) + today + m.group(2), new, count=1)
    errors = check(new, rows)
    if errors:
        for e in errors:
            print(f"FAIL {e}")
        sys.exit(f"{len(errors)} problem(s); nothing written")
    if new == html:
        print(f"the guide matches rules page {version}")
    else:
        backups = source / "backups"
        backups.mkdir(parents=True, exist_ok=True)
        shutil.copy2(guide, backups / f"seg-ai-data-guide-{stamp()}.html")
        guide.write_bytes(new.replace("\n", newline).encode("utf-8"))
        print(f"updated {GUIDE_NAME} to rules page {version}")
    if wording.exists():
        wording.replace(source / f"wording-applied-{stamp()}.json")
    for note in notes:
        print(f"note: {note}")
    flagged = request_wording(points, rows, source / "wording-request.md")
    if flagged:
        print(f"note: {len(flagged)} data point(s) use the rules page's wording (Nr {', '.join(map(str, flagged))});"
              " see source/wording-request.md")


def publish(guide, share, backups, ask):
    """Step 7: copies the guide to the network share after a "y", keeping the share's old file first.
    ask is input(), or None when there's no terminal to answer in."""
    if not share:
        print("set GUIDE_SHARE to publish; the guide is updated locally")
        return
    share = Path(share)
    if share.exists() and share.read_bytes() == guide.read_bytes():
        print(f"{share} already has this guide")
        return
    if ask is None:
        print(f"not published: no terminal to answer 'Publish to {share}?'; run it in a terminal to publish")
        return
    if ask(f"Publish to {share}? [y/N] ").strip().lower() not in ("y", "yes"):
        print("not published")
        return
    part = share.with_name(share.name + ".part")
    try:
        if share.exists():
            backups.mkdir(parents=True, exist_ok=True)
            shutil.copy2(share, backups / f"published-{stamp()}.html")
        # ponytail: a broken copy leaves <share>.part behind; the next publish overwrites it
        shutil.copy2(guide, part)
        os.replace(part, share)  # so that the share never holds half a guide
    except OSError as e:
        sys.exit(f"couldn't publish to {share}: {e}; the guide is updated locally")
    print(f"published to {share}")


def stops(fn, *args):
    """The message fn(*args) stops with; fails when it doesn't stop."""
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            fn(*args)
    except SystemExit as e:
        return str(e.code)
    raise AssertionError(f"{fn.__name__} didn't stop")


def selftest_render(html):
    """Rendering the real guide's data points gives back the data block byte for byte; returns how many there are."""
    points = block(html)[0]["dataPoints"]
    for dp in points:
        assert render(dp) in html, f"Nr {dp['row']} doesn't render to its own lines"
    assert with_points(html, points) == html, "rendering every data point must give back the guide byte for byte"
    flagged = render({**points[0], "pageWording": True})
    assert flagged.splitlines()[0].endswith(f'"src": "{points[0]["src"]}", "pageWording": true,'), flagged
    assert json.loads(flagged)["pageWording"] is True, "a flagged data point is still valid JSON"
    assert "isn't laid out" in stops(with_points, "<html></html>", points)
    return len(points)


RESULT_FOR = {"permitted": "Erlaubt / Permitted", "permitted_with_conditions": "Mit Bedingungen / With conditions",
              "internal_ai_only": "Nur intern (Knox/Gauss) / Internal only (Knox/Gauss)",
              "to_be_clarified": "Klärung nötig / To be clarified", "not_permitted": "Nicht erlaubt / Not permitted"}


def mirror_of(points):
    """A made-up rules page that matches the guide's data points: no real row text, only "point N"."""
    topic_for = {key: topic for topic, keys in CLUSTER_OF.items() for key in keys}
    return {dp["row"]: {"topic": topic_for[dp["cluster"]], "de": f"Punkt {dp['row']}", "en": f"point {dp['row']}",
                        "result": RESULT_FOR[dp["verdict"]],
                        "condition": "Only with approval." if dp["verdict"] == PWC else ""}
            for dp in points}


def synced(html, page):
    """html with every data point's src set to match page."""
    return with_points(html, [{**dp, "src": src_of(page[dp["row"]])} for dp in block(html)[0]["dataPoints"]])


def selftest_update(html):
    """Each row of the spec's table, on the mirror page with that one change; the updated guide must pass the check."""
    points = block(html)[0]["dataPoints"]
    mirror = mirror_of(points)
    guide = synced(html, mirror)
    assert not check(guide, mirror), "the guide must pass against its mirror page"
    first = {v: next(dp for dp in points if dp["verdict"] == v) for v in RESULT_FOR}  # any data point with that verdict
    pwc, ok, no = first[PWC]["row"], first["permitted"]["row"], first["not_permitted"]["row"]
    other = next(t for t, keys in CLUSTER_OF.items() if len(keys) == 1 and first["not_permitted"]["cluster"] not in keys)

    def after(edits):
        """(data points by Nr, changes, updated guide) once the mirror page gets edits: {Nr: {field: value}, or None to drop it}."""
        page = {nr: dict(r) for nr, r in mirror.items()}
        for nr, fields in edits.items():
            if fields is None:
                del page[nr]
            else:
                page[nr] = {**page.get(nr, {}), **fields}
        new = block(guide)[0]["dataPoints"]
        changes = update(new, page)
        text = with_points(guide, new)
        assert not check(text, page), f"the updated guide fails the check: {check(text, page)}"
        return {dp["row"]: dp for dp in new}, changes, text

    by, changes, text = after({})
    assert text == guide and not any(changes.values()), changes

    # The Nr is gone: the data point goes.
    by, changes, _ = after({no: None})
    assert no not in by and changes["removed"] == [f"Nr {no}: {first['not_permitted']['name']['en']} → removed (not on the rules page)"]

    # Only the result changed, and neither verdict is Permitted with conditions: verdict and src change, the wording stays.
    by, changes, _ = after({no: {"result": "Erlaubt / Permitted"}})
    assert by[no]["verdict"] == "permitted" and by[no]["name"] == first["not_permitted"]["name"] and "pageWording" not in by[no]
    assert changes["verdict changed"] == [f"Nr {no}: not_permitted → permitted (Erlaubt / Permitted)"], changes
    by, _, _ = after({no: {"result": "Rechtsprüfung offen / Legal review pending"}})
    assert by[no]["verdict"] == "not_permitted" and "pageWording" not in by[no]
    # "Klärung nötig" stays in the guide as To be clarified (ADR 0005).
    by, changes, _ = after({no: {"result": "Klärung nötig / To be clarified"}})
    assert by[no]["verdict"] == "to_be_clarified" and "pageWording" not in by[no] and not changes["removed"], changes
    assert changes["verdict changed"] == [f"Nr {no}: not_permitted → to_be_clarified (Klärung nötig / To be clarified)"], changes

    # Only the result changed, into, out of or within Permitted with conditions: name and condition get page wording.
    by, _, _ = after({ok: {"result": ANONYMISED}})
    assert by[ok]["pageWording"] and by[ok]["name"] == {"de": f"Punkt {ok}", "en": f"point {ok}"}
    assert by[ok]["condition"] == ANONYMISED_CONDITION, by[ok]
    by, _, _ = after({pwc: {"result": "Nicht erlaubt / Not permitted"}})
    assert by[pwc]["verdict"] == "not_permitted" and by[pwc]["pageWording"] and "condition" not in by[pwc]
    by, _, _ = after({pwc: {"result": ANONYMISED}})
    assert by[pwc]["condition"] == {lang: f"{s} Only with approval." for lang, s in ANONYMISED_CONDITION.items()}

    # The English text or the condition changed: page wording, keywords stay.
    by, changes, _ = after({no: {"en": f"point {no}, reworded"}})
    assert by[no]["name"]["en"] == f"point {no}, reworded" and by[no]["pageWording"]
    assert by[no]["keywords"] == first["not_permitted"]["keywords"]
    assert changes["reworded"] == [f"Nr {no}: {first['not_permitted']['name']['en']} → point {no}, reworded"]
    by, changes, _ = after({pwc: {"condition": "Only on Tuesdays."}})
    assert by[pwc]["condition"] == {"de": "Only on Tuesdays.", "en": "Only on Tuesdays."} and by[pwc]["pageWording"]
    assert changes["reworded"][0].endswith("(condition: Only on Tuesdays.)"), changes
    # Reworded with a new result at once: both show, so a looser verdict can't hide behind a rewording.
    by, changes, _ = after({no: {"en": f"point {no}, reworded", "result": "Erlaubt / Permitted"}})
    assert by[no]["verdict"] == "permitted" and by[no]["pageWording"]
    assert changes["verdict changed"] == [f"Nr {no}: not_permitted → permitted (Erlaubt / Permitted)"], changes

    # The topic no longer allows the data cluster: moved to the topic's default cluster, wording stays.
    by, changes, _ = after({no: {"topic": other}})
    cluster = next(iter(CLUSTER_OF[other]))
    assert by[no]["cluster"] == cluster and "pageWording" not in by[no]
    assert changes["moved"] == [f"Nr {no}: {first['not_permitted']['cluster']} → {cluster} ({other})"], changes

    # New Nrs go at the end, with page wording and the topic's halves as keywords.
    general = "Allgemeine Unternehmensinfos / General company information"
    new = {"de": "Neuer Punkt", "en": "new point", "condition": ""}
    by, changes, _ = after({500: {**new, "topic": general, "result": "Erlaubt / Permitted"},
                            501: {**new, "topic": "Preisdaten / Price data", "result": ANONYMISED}})
    assert list(by)[-2:] == [500, 501], "new data points go at the end"
    assert by[500]["cluster"] == "hq_basic" and by[500]["pageWording"] and "condition" not in by[500]
    assert by[500]["keywords"] == {"de": ["Allgemeine Unternehmensinfos"], "en": ["General company information"]}
    assert by[501]["cluster"] == "price" and by[501]["condition"] == ANONYMISED_CONDITION
    assert len(changes["new"]) == 2, changes

    # An unknown topic or result, or a topic with several data clusters and no default, stops the update.
    assert "unknown topic 'Neues / New'" in stops(update, block(guide)[0]["dataPoints"],
                                                  {**mirror, no: {**mirror[no], "topic": "Neues / New"}})
    assert "unknown result 'Vielleicht / Maybe'" in stops(update, block(guide)[0]["dataPoints"],
                                                          {**mirror, no: {**mirror[no], "result": "Vielleicht / Maybe"}})
    saved = DEFAULT_CLUSTER.pop(general)
    try:
        assert "has several data clusters" in stops(default_cluster, general)
    finally:
        DEFAULT_CLUSTER[general] = saved


def page_json(rows):
    """A made-up rules page REST response (version 29 of 2026-10-21) holding rows, {Nr: row}."""
    head = "".join(f"<th>{escape(name)}</th>" for name in cg.COLUMNS.values())
    body = "".join("<tr>" + "".join(f"<td>{escape(str(nr) if field == 'nr' else r[field])}</td>" for field in cg.COLUMNS)
                   + "</tr>" for nr, r in sorted(rows.items()))
    return json.dumps({"id": "1", "version": {"number": 29, "when": "2026-10-21T14:30:25.360+01:00"},
                       "body": {"storage": {"value": f"<table><tbody><tr>{head}</tr>{body}</tbody></table>"}}}).encode()


def selftest_fetch():
    """Fetching with urllib's urlopen swapped for a fake: only a usable page replaces the saved one."""
    good = page_json({1: {"topic": "Preisdaten / Price data", "de": "Punkt 1", "en": "point 1",
                          "result": "Erlaubt / Permitted", "condition": ""}})
    assert parse_rules(good)[1] == "version 29 of 2026-10-21"
    real, sent = urllib.request.urlopen, []

    def answer(reply):
        def fake(request, timeout):
            # The token goes only to RULES_URL: urllib copies request.headers, never unredirected ones, onto a redirect.
            sent.append((request.full_url, request.get_header("Authorization"), timeout, "Authorization" in request.headers))
            if isinstance(reply, Exception):
                raise reply
            return io.BytesIO(reply)
        return fake

    with tempfile.TemporaryDirectory() as tmp:
        saved = Path(tmp) / "source" / "confluence.json"
        assert "no token and no saved rules page" in stops(fetch, "", saved)
        try:
            urllib.request.urlopen = answer(good)
            assert fetch("secret", saved) == good and saved.read_bytes() == good, "a usable page is saved"
            assert sent[-1] == (RULES_URL, "Bearer secret", 60, False), sent
            for reply, expected in [
                (b"<html><body>Bitte anmelden</body></html>", "Confluence sent no usable rules page"),
                (urllib.error.HTTPError(RULES_URL, 401, "Unauthorized", {}, None), "Confluence refused the token"),
                (urllib.error.HTTPError(RULES_URL, 403, "Forbidden", {}, None), "Confluence refused the token"),
                (urllib.error.HTTPError(RULES_URL, 500, "Server Error", {}, None), "couldn't reach Confluence: HTTP 500"),
                (urllib.error.URLError("proxy said no"), "couldn't reach Confluence: proxy said no"),
                (TimeoutError("timed out"), "couldn't reach Confluence: timed out"),
            ]:
                urllib.request.urlopen = answer(reply)
                assert expected in stops(fetch, "secret", saved), expected
                assert saved.read_bytes() == good, f"{expected}: the saved page must stay"
        finally:
            urllib.request.urlopen = real
        assert fetch("", saved) == good, "no token: the saved page"
        assert not list(saved.parent.glob("*.part")), "no half-written file is left behind"


@contextlib.contextmanager
def workspace(text):
    """A temporary folder with text as the guide; yields (root, run_with), where run_with(page) saves page as the
    rules page, runs the update without a token on 2026-11-02, and returns what it printed."""
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        (root / "source").mkdir()
        (root / GUIDE_NAME).write_bytes(text.encode("utf-8"))

        def run_with(page):
            (root / "source" / "confluence.json").write_bytes(page_json(page))
            out = io.StringIO()
            try:
                with contextlib.redirect_stdout(out):
                    run(root, "", "2026-11-02")
            except SystemExit as e:
                sys.exit(out.getvalue() + str(e.code))  # so that stops() also sees what the run printed
            return out.getvalue()

        yield root, run_with


def selftest_run(html):
    """The run on a copy of the guide in a temporary folder: what it writes, and that a failed step writes nothing."""
    mirror = mirror_of(block(html)[0]["dataPoints"])
    start = synced(html, mirror)
    no = next(nr for nr, r in mirror.items() if r["result"] == RESULT_FOR["not_permitted"])
    changed = {**mirror, no: {**mirror[no], "result": "Erlaubt / Permitted"}}
    with workspace(start) as (root, run_with):
        guide, source = root / GUIDE_NAME, root / "source"
        out = run_with(mirror)
        assert "the guide matches rules page version 29 of 2026-10-21" in out, out
        assert guide.read_bytes() == start.encode("utf-8") and not (source / "backups").exists(), "nothing to do writes nothing"

        out = run_with(changed)
        assert f"verdict changed: Nr {no}: not_permitted → permitted (Erlaubt / Permitted)" in out, out
        updated = guide.read_bytes().decode("utf-8")
        assert '"asOf": "2026-11-02"' in updated and not check(updated, changed)
        assert [b.read_bytes() for b in (source / "backups").iterdir()] == [start.encode("utf-8")], "the old guide is kept first"
        assert "the guide matches" in run_with(changed) and guide.read_bytes().decode("utf-8") == updated, "a second run changes nothing"

        # A step that fails writes nothing.
        def edited(**fields):
            return {**changed, no: {**changed[no], **fields}}
        for page, expected in [
            (edited(topic="Neues / New"), ["unknown topic 'Neues / New'"]),
            (edited(result="Mit Bedingungen / With conditions"),  # an empty condition cell
             [f"FAIL Nr {no} condition: needs German and English text", "nothing written"]),
            (edited(en="Only after DPO approval"),  # page text the check's leak rules reject; the change list names the row
             [f"reworded: Nr {no}:", "FAIL review wording", "nothing written"]),
        ]:
            message = stops(run_with, page)
            assert all(e in message for e in expected), message
            assert guide.read_bytes().decode("utf-8") == updated, f"{expected}: the guide must stay"
            assert len(list((source / "backups").iterdir())) == 1, f"{expected}: no backup either"

        # A guide saved with CRLF line ends stays CRLF.
        guide.write_bytes(updated.replace("\n", "\r\n").encode("utf-8"))
        run_with(mirror)
        assert b"\n" not in guide.read_bytes().replace(b"\r\n", b""), "line ends must stay CRLF"

        # wording-request.md lists the data points with page wording, and goes once there are none.
        added = {**mirror, 500: {"topic": "Preisdaten / Price data", "de": "Neuer Punkt", "en": "new point",
                                 "result": "Erlaubt / Permitted", "condition": ""}}
        assert "1 data point(s) use the rules page's wording (Nr 500)" in run_with(added)
        request = (source / "wording-request.md").read_text(encoding="utf-8")
        assert "## Nr 500" in request and "new point" in request and "wie im {link} beschrieben" in request, request
        assert "the guide matches" in run_with(added), "page wording alone is nothing to do"
        assert "removed: Nr 500" in run_with(mirror) and not (source / "wording-request.md").exists()


def selftest_wording(html):
    """source/wording.json: a valid answer replaces page wording; a broken one stops the run with nothing written."""
    mirror = mirror_of(block(html)[0]["dataPoints"])
    ok = next(nr for nr, r in mirror.items() if r["result"] == RESULT_FOR["permitted"])
    new = {"topic": "Preisdaten / Price data", "de": "Neuer Punkt", "en": "new point", "condition": ""}
    page = {**mirror, 500: {**new, "result": ANONYMISED}, 501: {**new, "result": "Erlaubt / Permitted"}}
    polished = {"name": {"de": "Aktionspreise", "en": "Promotion prices"},
                "condition": {"de": "Nur anonymisiert, wie im {link} beschrieben.",
                              "en": "Only anonymised, as described in the {link}."},
                "keywords": {"de": ["Aktion"], "en": ["promotion"]}}
    with workspace(synced(html, mirror)) as (root, run_with):
        guide, wording = root / GUIDE_NAME, root / "source" / "wording.json"
        run_with(page)  # Nr 500 and 501 go in with page wording

        def answer(value, encoding="utf-8"):
            wording.write_text(json.dumps(value, ensure_ascii=False), encoding=encoding)

        before = guide.read_bytes()
        for value, expected in [
            ({"500": {**polished, "name": {"de": "Aktionspreise"}}}, "Nr 500 name: needs German and English text"),
            ({"500": {**polished, "condition": {"de": "Nur anonymisiert.", "en": polished["condition"]["en"]}}},
             "Nr 500 condition: German and English need the same {placeholders}"),
            ({"500": {**polished, "condition": None}}, "Nr 500 condition: needs German and English text"),
            ({"500": {**polished, "keywords": {"de": "Aktion", "en": "promotion"}}}, "Nr 500 keywords: need a list"),
            ({"501": polished}, "Nr 501: only 'Permitted with conditions' carries a condition"),
            (["not", "keyed", "by", "Nr"], "expected {"),
        ]:
            answer(value)
            assert expected in stops(run_with, page), expected
            assert guide.read_bytes() == before and wording.exists(), f"{expected}: nothing written"
        wording.write_text("{not json", encoding="utf-8")
        assert "isn't valid JSON" in stops(run_with, page)

        answer({"500": polished, str(ok): polished}, encoding="utf-8-sig")  # Notepad saves with a BOM
        out = run_with(page)
        assert f"Nr {ok}: has no page wording in the guide, skipped" in out, out
        assert "Nr 500: polished wording applied" in out, out
        by = {dp["row"]: dp for dp in block(guide.read_bytes().decode("utf-8"))[0]["dataPoints"]}
        assert by[500]["name"] == polished["name"] and by[500]["keywords"] == polished["keywords"]
        assert by[500]["condition"] == polished["condition"] and "pageWording" not in by[500]
        assert by[ok]["name"] != polished["name"], "an Nr without page wording keeps its wording"
        assert not wording.exists() and list((root / "source").glob("wording-applied-*.json")), "the answer is renamed once applied"
        request = (root / "source" / "wording-request.md").read_text(encoding="utf-8")
        assert "## Nr 501" in request and "## Nr 500" not in request, request


def selftest_publish():
    """Publishing: only after a "y", only when the share's file differs, and the share's old file is kept first."""
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        guide, share, backups = root / GUIDE_NAME, root / "share" / GUIDE_NAME, root / "source" / "backups"
        guide.write_text("new guide", encoding="utf-8")
        share.parent.mkdir()
        share.write_text("old guide", encoding="utf-8")

        def publish_with(reply, where=str(share)):
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                publish(guide, where, backups, reply if reply is None or callable(reply) else (lambda prompt: reply))
            return out.getvalue()

        assert "set GUIDE_SHARE to publish; the guide is updated locally" in publish_with("y", "")
        assert "no terminal" in publish_with(None) and share.read_text(encoding="utf-8") == "old guide"
        assert "not published" in publish_with("") and share.read_text(encoding="utf-8") == "old guide", "Enter means no"
        assert "published to" in publish_with("y") and share.read_text(encoding="utf-8") == "new guide"
        assert [p.read_text(encoding="utf-8") for p in backups.glob("published-*.html")] == ["old guide"]

        def never(prompt):
            raise AssertionError("asked although the share already has this guide")
        assert "already has this guide" in publish_with(never)
        assert "couldn't publish" in stops(publish, guide, str(root / "missing" / GUIDE_NAME), backups, lambda prompt: "y")

        # A copy that breaks off half-way, say when the network drops, leaves the share's file as it was.
        share.write_text("old guide", encoding="utf-8")
        real_copy = shutil.copy2

        def broken(src, dst):
            if Path(dst).parent == share.parent:
                Path(dst).write_text("new gu", encoding="utf-8")
                raise OSError("the network name is no longer available")
            return real_copy(src, dst)
        shutil.copy2 = broken
        try:
            assert "couldn't publish" in stops(publish, guide, str(share), backups, lambda prompt: "y")
        finally:
            shutil.copy2 = real_copy
        assert share.read_text(encoding="utf-8") == "old guide", "a broken copy must not leave half a guide on the share"


def selftest_output():
    """On a cp1252 laptop, output to a file or an agent can't encode →; it must print ? rather than stop half-way
    through a run that has already written the guide."""
    real = sys.stdout
    sys.stdout = io.TextIOWrapper(io.BytesIO(), encoding="cp1252")
    try:
        plain_output()
        print("verdict changed: Nr 1: not_permitted → permitted")
    finally:
        sys.stdout = real


def selftest_terminal():
    """Stdin from NUL, as when an agent or a script starts the run, is no terminal, though Windows calls NUL a tty."""
    real = sys.stdin
    with open(os.devnull) as nul:
        sys.stdin = nul
        try:
            assert not interactive(), "stdin from NUL must not count as a terminal"
        finally:
            sys.stdin = real


def selftest():
    """Every case of the update, on made-up rules pages; nothing is written outside a temporary folder."""
    html = read_guide(ROOT / GUIDE_NAME)[0]  # read only
    n = selftest_render(html)
    selftest_update(html)
    selftest_fetch()
    selftest_run(html)
    selftest_terminal()
    selftest_wording(html)
    selftest_publish()
    selftest_output()
    print(f"selftest: all {n} data points render byte for byte; every update, fetch, run, wording and publish case passes")


def main():
    if "--selftest" in sys.argv:
        return selftest()
    plain_output()
    terminal = interactive()
    token = os.environ.get("CONFLUENCE_TOKEN", "").strip() or (
        getpass.getpass("Confluence personal access token (Enter: use the saved page): ").strip() if terminal else "")
    run(ROOT, token, date.today().isoformat())
    publish(ROOT / GUIDE_NAME, os.environ.get("GUIDE_SHARE", ""), ROOT / "source" / "backups", input if terminal else None)


if __name__ == "__main__":
    main()
