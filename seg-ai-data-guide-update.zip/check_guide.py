"""Content check for the SEG AI Data Guide.

    python -I check_guide.py             check the guide against the rules page (source/confluence.json) and the agreed rules
    python -I check_guide.py --selftest  prove every rule still catches the mistake it guards against
"""
import hashlib
import json
import re
import sys
from datetime import date
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
GUIDE = ROOT / "seg-ai-data-guide.html"
RULES_PAGE = ROOT / "source" / "confluence.json"  # the rules page's REST response, saved on the company laptop
RULES_URL = "https://confluence-eu.sec.samsung.net/rest/api/content/1023761281?expand=body.storage,version"
# The rules table's columns; header cells match with spaces ignored (the page has "Bedingung/ Condition").
COLUMNS = {"nr": "Nr", "topic": "Thema / Topic", "de": "Datenpunkt (DE)", "en": "Data point (EN)",
           "result": "Ergebnis / Result", "condition": "Bedingung / Condition"}
# The rules page's results, as its own legend reads them (ADR 0003); "To be clarified" leads to Clarify first (ADR 0005).
RESULT_OF = {"Erlaubt / Permitted": "permitted",
             "Mit Bedingungen / With conditions": "permitted_with_conditions",
             "Nur anonymisiert / Only if anonymized": "permitted_with_conditions",
             "Nur intern (Knox/Gauss) / Internal only (Knox/Gauss)": "internal_ai_only",
             "Nicht erlaubt / Not permitted": "not_permitted",
             "Rechtsprüfung offen / Legal review pending": "not_permitted",
             "Klärung nötig / To be clarified": "to_be_clarified"}
# Each rules page topic and the data clusters a data point under it may use.
CLUSTER_OF = {"Allgemeine Unternehmensinfos / General company information": {"hq_basic", "hq_critical"},
              "Personenbezogene Daten / Personal data": {"personal"},
              "Nicht-personenbezogene Kunden-/Partnerdaten / Non-personal customer/partner data": {"customer_master"},
              "Finanz- und Leistungsdaten / Finance & performance data": {"finance"},
              "Markt- und Vertriebsdaten / Market & sales data": {"market_sales"},
              "Produktdaten / Product data": {"product"},
              "Preisdaten / Price data": {"price"},
              "Strategische und sensible Daten / Strategic & sensitive data": {"strategy"},
              "Sicherheitsrelevante Daten / Security-relevant data": {"security"},
              "Betriebsdaten / Operational data": {"operations"},
              "Marketing- und Werbedaten / Marketing & advertising data": {"marketing"},
              "Compliance und Datenschutz / Compliance & data protection": {"compliance"},
              "Öffentliche und allgemeine Daten / Public & generic data": {"public"}}
VERDICTS = ["not_permitted", "to_be_clarified", "internal_ai_only", "permitted_with_conditions", "permitted"]  # strictest first
OUTCOMES = ["not_permitted", "clarify_first", "internal_ai_only", "permitted_with_conditions", "permitted"]  # the data check's
LANGS = ("de", "en")
PENDING = "PENDING"

BLOCK = re.compile(r'<script type="application/json" id="guide-data">(.*?)</script>', re.S)
URL = re.compile(r"(?:https?:)?//[\w-]+(?:\.[\w-]+)+[^\s\"'<>)]*", re.I)
REQUEST = re.compile(r"<link\b|@import|\bsrc\s*=\s*[\"'](?!data:)|\bfetch\s*\(|XMLHttpRequest|WebSocket"
                     r"|sendBeacon|\bimport\s*\(")
PLACEHOLDER = re.compile(r"\{\w+\}")
IP = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}\b")
HOST = re.compile(r"\b[A-Z]{2,}-[A-Z0-9]{3,}\d\b")
REVIEW_WORDING = re.compile(r"legal review|review status|approved as recommended|approved with changes"
                            r"|proposal:|please validate|\bDPO\b|\bArt\.\s*\d|\bBDSG\b|\bBetrVG\b|\bGWB\b"
                            r"|\bTFEU\b|§|\brows? \d", re.I)


class Tables(HTMLParser):
    """Every table on a page, as rows of cell texts with whitespace (any Unicode space) collapsed."""

    def __init__(self):
        super().__init__()
        self.tables, self.cell = [], None

    def handle_starttag(self, tag, attrs):
        if tag == "table":
            self.tables.append([])
        elif tag == "tr" and self.tables:
            self.tables[-1].append([])
        elif tag in ("td", "th"):
            self.cell = []
        elif tag in ("br", "p", "li") and self.cell is not None:
            self.cell.append(" ")

    def handle_endtag(self, tag):
        if tag in ("td", "th") and self.cell is not None:
            self.tables[-1][-1].append(" ".join("".join(self.cell).split()))
            self.cell = None

    def handle_data(self, data):
        if self.cell is not None:
            self.cell.append(data)


def parse_rules(data):
    """({Nr: {topic, de, en, result, condition}}, "version N of DATE") from the saved REST response of the rules page.
    Raises ValueError saying what to do when the file isn't a usable copy of the page."""
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise ValueError("the file is not UTF-8; save or paste it again as UTF-8") from None
    try:
        page = json.loads(text)
        storage = page["body"]["storage"]["value"]
    except (ValueError, KeyError, TypeError):
        raise ValueError(f"this isn't the rules page's JSON (a login page?): log in to Confluence,"
                         f" then save {RULES_URL} again") from None
    parser = Tables()
    parser.feed(storage)
    found = [t for t in parser.tables if t and "Nr" in t[0]]
    if not found:
        raise ValueError("the page has no table with an 'Nr' column")
    if len(found) > 1:
        raise ValueError(f"the page has {len(found)} tables with an 'Nr' column; expected one rules table")
    head, *body = found[0]
    squash = lambda s: "".join(s.split())
    keys = [squash(h) for h in head]
    missing = [name for name in COLUMNS.values() if squash(name) not in keys]
    if missing:
        raise ValueError(f"the rules table has no column {', '.join(repr(m) for m in missing)}")
    at = {field: keys.index(squash(name)) for field, name in COLUMNS.items()}
    rows = {}
    for i, cells in enumerate(body, 2):  # row 1 is the header
        if not any(cells):
            continue  # Confluence often leaves an empty last row
        if len(cells) != len(head):
            raise ValueError(f"table row {i} has {len(cells)} cells, the header has {len(head)}")
        nr = cells[at["nr"]]
        if not (nr.isascii() and nr.isdigit()):
            raise ValueError(f"table row {i}: Nr {nr!r} is not a whole number")
        if int(nr) in rows:
            raise ValueError(f"Nr {nr} appears more than once")
        rows[int(nr)] = {field: cells[col] for field, col in at.items() if field != "nr"}
    if not rows:
        raise ValueError("the rules table has no rows")
    version = page.get("version") or {}
    return rows, f"version {version.get('number', '?')} of {str(version.get('when', '?'))[:10]}"


def src_of(row):
    """The fingerprint of a rules page row's English text, condition and result, which a data point's src must match."""
    return hashlib.sha256(f"{row['en']}\n{row['condition']}\n{row['result']}".encode()).hexdigest()[:6]


def rules_page():
    """The rules page's rows ({Nr: row}) from source/confluence.json, or None when the file isn't there."""
    if not RULES_PAGE.exists():
        return None
    try:
        rows, version = parse_rules(RULES_PAGE.read_bytes())
    except ValueError as e:
        sys.exit(f"rules page ({RULES_PAGE.name}): {e}")
    print(f"rules page {version}: {len(rows)} rows")
    return rows


def block(html):
    """(data, None) for a readable data block, else (None, the reason)."""
    found = BLOCK.search(html)
    if not found:
        return None, "data block not found"
    try:
        return json.loads(found.group(1)), None
    except json.JSONDecodeError as e:
        return None, f"data block is not valid JSON: {e}"


def texts(errors):
    """both(text, where) checks one {de, en} text; walk(data) afterwards checks every text both() hasn't seen."""
    checked = {}  # id -> text object already checked by both(); holding the object keeps its id unique

    def both(text, where):
        checked[id(text)] = text
        if not isinstance(text, dict) or not all(text.get(lang) and str(text[lang]).strip() for lang in LANGS):
            errors.append(f"{where}: needs German and English text")
        elif len({frozenset(PLACEHOLDER.findall(str(text[lang]))) for lang in LANGS}) > 1:
            errors.append(f"{where}: German and English need the same {{placeholders}}")

    def walk(node, path=""):
        if isinstance(node, dict):
            if ("de" in node or "en" in node) and id(node) not in checked:
                both(node, path)
            for key, value in node.items():
                walk(value, f"{path}.{key}" if path else key)
        elif isinstance(node, list):
            for i, value in enumerate(node):
                walk(value, f"{path}[{i}]")

    return both, walk


def file_rules(html, data, both):
    """What every published file needs: a valid date, ui texts and links, and nothing loaded or leaked."""
    errors = []
    as_of = str(data.get("meta", {}).get("asOf", ""))
    try:
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", as_of):
            raise ValueError
        date.fromisoformat(as_of)
    except ValueError:
        errors.append(f"meta.asOf: {as_of!r} is not a YYYY-MM-DD date")

    ui = data.get("ui", {})
    for key in sorted(set(ui.get("de", {})) | set(ui.get("en", {}))):
        both({lang: ui.get(lang, {}).get(key) for lang in LANGS}, f"ui.{key}")

    links = data.get("links", {})
    for key, link in links.items():
        url = link.get("url", "")
        if key == "logo":
            if url and not url.startswith("data:image/"):
                errors.append("links.logo: must be empty or an inline data:image/ URI")
            continue
        if url != PENDING and not url.startswith("https://"):
            errors.append(f"links.{key}: must be {PENDING} or an https:// address")
        both(link.get("label"), f"links.{key} label")

    allowed = {link.get("url") for link in links.values()}
    errors += [f"external URL outside the configured links: {u}" for u in URL.findall(html) if u not in allowed]
    errors += [f"external resource or network call: {hit!r}" for hit in REQUEST.findall(html)]
    errors += [f"IP address: {hit}" for hit in IP.findall(html)]
    errors += [f"server name: {hit}" for hit in HOST.findall(html)]
    errors += [f"review wording or legal citation: {hit!r}" for hit in REVIEW_WORDING.findall(html)]
    return errors


def check(html, rules):
    """Every problem in the guide, as readable messages; an empty list means the guide passes.
    rules is the rules page ({Nr: row}), or None to check the guide on its own."""
    data, problem = block(html)
    if problem:
        return [problem]
    errors = []
    both, walk = texts(errors)
    errors += file_rules(html, data, both)

    # Every published Nr and its verdict: from the rules page, else (no page) the guide's own.
    if rules is None:
        verdict_of = {dp.get("row"): dp.get("verdict") for dp in data.get("dataPoints", [])}
    else:
        verdict_of = {}
        for nr, r in sorted(rules.items()):
            if r["topic"] not in CLUSTER_OF:
                errors.append(f"Nr {nr}: unknown topic {r['topic']!r} on the rules page; add it to CLUSTER_OF")
            if r["result"] not in RESULT_OF:
                errors.append(f"Nr {nr}: unknown result {r['result']!r} on the rules page")
            else:
                verdict_of[nr] = RESULT_OF[r["result"]]

    ranked = sorted(data.get("verdicts", []), key=lambda v: v.get("rank", 0))
    if [v.get("key") for v in ranked] != VERDICTS:
        errors.append("verdicts: need exactly the five verdicts, ranked strictest first")
    for v in ranked:
        both(v.get("label"), f"verdict {v.get('key')} label")
        both(v.get("short"), f"verdict {v.get('key')} short")  # the one-word tag in the data check
        both(v.get("meaning"), f"verdict {v.get('key')} meaning")

    outcomes = data.get("outcomes")
    if not isinstance(outcomes, dict) or sorted(outcomes) != sorted(OUTCOMES):
        errors.append(f"outcomes: need exactly the five outcomes {OUTCOMES}")
        outcomes = outcomes if isinstance(outcomes, dict) else {}
    for key in OUTCOMES:
        for field in ("heading", "reason", "whatToDo"):
            both((outcomes.get(key) or {}).get(field), f"outcome {key} {field}")

    clusters = {c.get("key") for c in data.get("clusters", [])}
    for c in data.get("clusters", []):
        both(c.get("name"), f"data cluster {c.get('key')}")
        both(c.get("hint"), f"data cluster {c.get('key')} hint")  # the example line on its question 1 tile
        if not re.fullmatch(r"[a-z_]+", str(c.get("key"))):
            errors.append(f"data cluster key {c.get('key')!r}: use only a-z and _")

    seen = set()
    for dp in data.get("dataPoints", []):
        row = dp.get("row")
        where = f"Nr {row}"
        if row in seen:
            errors.append(f"{where}: appears more than once")
        seen.add(row)
        if dp.get("cluster") not in clusters:
            errors.append(f"{where}: unknown data cluster {dp.get('cluster')!r}")
        if dp.get("verdict") not in VERDICTS:
            errors.append(f"{where}: unknown verdict {dp.get('verdict')!r}")
        both(dp.get("name"), f"{where} name")
        both(dp.get("keywords"), f"{where} keywords")
        if dp.get("verdict") == "permitted_with_conditions":
            both(dp.get("condition"), f"{where} condition")
        elif "condition" in dp:
            errors.append(f"{where}: only 'Permitted with conditions' carries a condition")
        if rules is None:
            continue
        r = rules.get(row)
        if r is None:
            errors.append(f"{where}: not on the rules page")
        elif row in verdict_of:
            if dp.get("verdict") != verdict_of[row]:
                errors.append(f"{where}: verdict {dp.get('verdict')!r}, the rules page says {verdict_of[row]!r} ({r['result']})")
            allowed = CLUSTER_OF.get(r["topic"])
            if allowed and dp.get("cluster") not in allowed:
                errors.append(f"{where}: data cluster {dp.get('cluster')!r}, its topic {r['topic']!r} allows {sorted(allowed)}")
            if dp.get("src") != src_of(r):
                errors.append(f"{where}: its text on the rules page is new or changed since this wording was written:"
                              f" {r['en']!r}, condition {r['condition'] or '(none)'!r}."
                              f" Check its name, condition and Nr, then set src to {src_of(r)!r}")
    if rules is not None:
        errors += [f"Nr {nr}: new on the rules page, not in the guide ({rules[nr]['en']})"
                   for nr in sorted(set(verdict_of) - seen)]

    walk(data)
    return errors


def selftest_rules_page():
    """The rules page reader, on a made-up page with no real rows; returns how many broken pages it caught."""
    def page(rules_table, extra=""):
        legend = ('<table><tbody><tr><td><p><strong>Ergebnis / Result</strong></p></td><td><p>Bedeutung (DE)</p></td></tr>'
                  '<tr><td>Erlaubt / Permitted</td><td>Darf verwendet werden.</td></tr></tbody></table>')
        return json.dumps({"id": "1", "version": {"number": 3, "when": "2026-10-21T14:30:25.360+01:00"},
                           "body": {"storage": {"value": legend + extra + rules_table}}}).encode()

    head = "".join(f"<td><strong>{h}</strong></td>" for h in
                   ("Thema / Topic", "Nr", "Data point (EN)", "Datenpunkt (DE)", "Ergebnis / Result", "Bedingung/ Condition"))

    def table(*rows):
        return ("<table><tbody><tr>" + head + "</tr>"
                + "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows) + "</tbody></table>")

    good = table(
        ["Finanz- und Leistungsdaten / Finance &amp; performance data", "1", "<p>Test&nbsp;point</p><p>one</p>",
         "Testpunkt", "<strong>Mit Bedingungen / With conditions</strong>", "Only with   approval."],
        ["Preisdaten / Price data", " 2 ", "Point two", "Punkt zwei", "Nicht erlaubt / Not permitted", "　"],
        ["", "", "", "", "", ""],  # Confluence often leaves an empty last row
    )
    rows, version = parse_rules(page(good))
    assert version == "version 3 of 2026-10-21", version
    assert rows == {
        1: {"topic": "Finanz- und Leistungsdaten / Finance & performance data", "en": "Test point one", "de": "Testpunkt",
            "result": "Mit Bedingungen / With conditions", "condition": "Only with approval."},
        2: {"topic": "Preisdaten / Price data", "en": "Point two", "de": "Punkt zwei",
            "result": "Nicht erlaubt / Not permitted", "condition": ""},
    }, rows
    assert src_of(rows[2]) == hashlib.sha256(b"Point two\n\nNicht erlaubt / Not permitted").hexdigest()[:6]
    unversioned = json.loads(page(good))
    del unversioned["version"]
    assert parse_rules(json.dumps(unversioned).encode())[1] == "version ? of ?"

    x = ["Preisdaten / Price data", "2", "x", "x", "Nicht erlaubt / Not permitted", "x"]
    broken = [
        ("this isn't the rules page's JSON", b"<html><body>Bitte anmelden</body></html>"),
        ("the file is not UTF-8", page(good).decode().encode("utf-16")),
        ("the page has no table with an 'Nr' column", page("")),
        ("the page has 2 tables with an 'Nr' column", page(good, good)),
        ("the rules table has no column 'Data point (EN)'", page(good.replace("Data point (EN)", "Data point"))),
        ("table row 2 has 5 cells, the header has 6", page(table(x[:5]))),
        ("table row 2: Nr '2a' is not a whole number", page(table([x[0], "2a", *x[2:]]))),
        ("Nr 2 appears more than once", page(table(x, x))),
        ("the rules table has no rows", page(table())),
    ]
    for expected, data in broken:
        try:
            parse_rules(data)
        except ValueError as e:
            assert expected in str(e), f"rules page reader: expected {expected!r}, got {e}"
        else:
            raise AssertionError(f"rules page reader missed: {expected}")
    return len(broken)


def selftest(html):
    """Break the real guide in each way the check guards against, and confirm the check notices."""
    reader = selftest_rules_page()
    assert not check(html, None), "the guide must pass before the selftest means anything"

    def changed(edit):
        d = json.loads(BLOCK.search(html).group(1))
        edit(d)
        new = f'<script type="application/json" id="guide-data">{json.dumps(d, ensure_ascii=False)}</script>'
        return BLOCK.sub(lambda _: new, html, count=1)

    def dp(d, row):
        return next(x for x in d["dataPoints"] if x["row"] == row)

    def add(d, row):
        d["dataPoints"].append({**dp(d, 65), "row": row})

    cases = [
        ("Nr 42 name", changed(lambda d: dp(d, 42)["name"].pop("en"))),
        ("Nr 42 condition", changed(lambda d: dp(d, 42).pop("condition"))),
        ("Nr 65: only", changed(lambda d: dp(d, 65).update(condition={"de": "x", "en": "x"}))),
        ("Nr 65: appears more than once", changed(lambda d: add(d, 65))),
        ("meta.note: needs German", changed(lambda d: d["meta"].update(note={"de": "nur Deutsch"}))),
        ("outcomes: need exactly the five", changed(lambda d: d["outcomes"].pop("clarify_first"))),
        ("outcomes: need exactly the five", changed(lambda d: d["outcomes"].update(maybe=d["outcomes"]["permitted"]))),
        ("outcome permitted reason: needs German", changed(lambda d: d["outcomes"]["permitted"]["reason"].pop("en"))),
        ("outcome not_permitted whatToDo: needs German", changed(lambda d: d["outcomes"]["not_permitted"].pop("whatToDo"))),
        ("ui.nPoints: German and English need the same {placeholders}",
         changed(lambda d: d["ui"]["en"].update(nPoints="{n} of {all} data points"))),
        ("ui.footer: German and English need the same {placeholders}",
         changed(lambda d: d["ui"]["de"].update(footer="Dieser Guide gilt zusammen mit der KI-Richtlinie."))),
        ("meta.asOf: '2026-13-01' is not a YYYY-MM-DD date", changed(lambda d: d["meta"].update(asOf="2026-13-01"))),
        ("meta.asOf: '16.10.2026' is not a YYYY-MM-DD date", changed(lambda d: d["meta"].update(asOf="16.10.2026"))),
        ("data cluster key 'Price-Data': use only", changed(lambda d: d["clusters"].append(
            {"key": "Price-Data", "name": {"de": "Preise", "en": "Prices"}}))),
        ("data cluster product hint: needs German", changed(lambda d: next(
            c for c in d["clusters"] if c["key"] == "product").pop("hint"))),
        ("verdict permitted short: needs German", changed(lambda d: next(
            v for v in d["verdicts"] if v["key"] == "permitted").pop("short"))),
        ("external resource", html.replace("</body>", '<script src="https://cdn.example.com/x.js"></script></body>')),
        ("external URL", html.replace("</body>", "<p>see https://example.com/page</p></body>")),
        ("IP address", html.replace("</body>", "<p>10.20.30.40</p></body>")),
        ("server name", html.replace("</body>", "<p>ABC-SRVDB1</p></body>")),
        ("review wording", html.replace("</body>", "<p>Legal review pending</p></body>")),
        ("legal citation", html.replace("</body>", "<p>Art. 9</p></body>")),
    ]
    for expected, broken in cases:
        errors = check(broken, None)
        assert any(expected in e for e in errors), f"check missed: {expected} (got {errors})"

    # The guide against a rules page made from the guide itself, so that the guide passes; then break the page.
    result_for = {"permitted": "Erlaubt / Permitted", "permitted_with_conditions": "Mit Bedingungen / With conditions",
                  "internal_ai_only": "Nur intern (Knox/Gauss) / Internal only (Knox/Gauss)",
                  "to_be_clarified": "Klärung nötig / To be clarified", "not_permitted": "Nicht erlaubt / Not permitted"}
    topic_for = {key: topic for topic, keys in CLUSTER_OF.items() for key in keys}
    mirror = {x["row"]: {"topic": topic_for[x["cluster"]], "de": "x", "en": f"point {x['row']}",
                         "result": result_for[x["verdict"]], "condition": ""} for x in block(html)[0]["dataPoints"]}
    def synced_to(page):
        return changed(lambda d: [x.update(src=src_of(page[x["row"]])) for x in d["dataPoints"]])

    def mirror_with(nr, **fields):
        return {**mirror, nr: {**mirror[nr], **fields}}

    synced = synced_to(mirror)
    assert not check(synced, mirror), "the guide must pass against a rules page made from it"
    for fine in (mirror_with(65, result="Rechtsprüfung offen / Legal review pending"),
                 mirror_with(42, result="Nur anonymisiert / Only if anonymized")):
        assert not check(synced_to(fine), fine), f"legend mapping rejected: {check(synced_to(fine), fine)}"
    page_cases = [
        ("Nr 65: verdict 'not_permitted', the rules page says 'permitted'", mirror_with(65, result="Erlaubt / Permitted")),
        ("Nr 65: verdict 'not_permitted', the rules page says 'to_be_clarified'",
         mirror_with(65, result="Klärung nötig / To be clarified")),
        ("Nr 65: unknown result 'Vielleicht / Maybe'", mirror_with(65, result="Vielleicht / Maybe")),
        ("Nr 65: unknown topic 'Neues / New'", mirror_with(65, topic="Neues / New")),
        ("Nr 65: data cluster 'security', its topic 'Preisdaten / Price data' allows ['price']",
         mirror_with(65, topic="Preisdaten / Price data")),
        ("Nr 65: its text on the rules page is new or changed", mirror_with(65, en="point 65, reworded")),
        ("Nr 42: its text on the rules page is new or changed", mirror_with(42, condition="Only on Tuesdays.")),
        # same verdict, different result: the guide's condition may no longer say what the page asks
        ("Nr 42: its text on the rules page is new or changed", mirror_with(42, result="Nur anonymisiert / Only if anonymized")),
        ("Nr 65: not on the rules page", {nr: r for nr, r in mirror.items() if nr != 65}),
        ("Nr 500: new on the rules page, not in the guide (point 500)", {**mirror, 500: {**mirror[65], "en": "point 500"}}),
    ]
    for expected, page in page_cases:
        errors = check(synced, page)
        assert any(expected in e for e in errors), f"rules page check missed: {expected} (got {errors})"

    print(f"selftest: rules page reader ({reader} broken pages), all {len(cases)} guide and {len(page_cases)} rules page"
          " cases caught")


def main():
    if not GUIDE.exists():
        sys.exit(f"not found: {GUIDE.name}")
    html = GUIDE.read_text(encoding="utf-8")
    if "--selftest" in sys.argv:
        return selftest(html)
    rules = rules_page()
    if rules is None:
        print(f"note: source/{RULES_PAGE.name} not found; rules page comparison skipped")
    errors = check(html, rules)
    for e in errors:
        print(f"FAIL {e}")
    if errors:
        sys.exit(f"{len(errors)} problem(s)")
    against = "match the rules page" if rules is not None else "pass on their own (rules page not compared)"
    print(f"ok: the guide's {len(block(html)[0]['dataPoints'])} data points {against}")


if __name__ == "__main__":
    main()
