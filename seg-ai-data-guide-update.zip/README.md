# SEG AI Data Guide: maintainer notes

The guide is one file, `seg-ai-data-guide.html`. It opens in any browser and needs no network.

## Keeping the guide up to date

SEG keeps the rules on its Confluence page "Confidential Data Usage" and changes them over time (ADR 0003). The guide never reads Confluence itself. Instead, `update_guide.py` on the company laptop does the whole update (ADR 0004): it fetches the page, brings the guide's data in step, checks it and, after your "y", publishes it.

**When:** whenever SEG says the page changed, and otherwise once a month.

**Setup, once (company laptop).**
1. Make a folder with `check_guide.py`, `update_guide.py`, `seg-ai-data-guide.html` and `README.md`. `source/` is created on the first run.
2. Optionally set the published file: `setx GUIDE_SHARE "\\server\share\seg-ai-data-guide.html"`.
3. Optionally set `CONFLUENCE_TOKEN` to a personal access token (Confluence › Profile › Personal Access Tokens). If it isn't set, the script asks for the token each time. It never stores it.

**Running it.** Open a terminal in the folder and run `python -I update_guide.py`. It:
1. fetches the rules page. Pressing Enter at the token prompt uses the saved `source/confluence.json`.
2. applies `source/wording.json`, if there is one (see "Page wording");
3. updates the data block as the page says: it removes data points, adds them, changes verdicts and moves them to another data cluster;
4. checks the result, and stops without writing anything if the check fails;
5. keeps the old guide in `source/backups/`, writes the new one, and sets `meta.asOf` to today. `meta.version` stays; raise it by hand for bigger releases.
6. lists every change;
7. asks `Publish to …? [y/N]`. On "y", it keeps the share's old file in `source/backups/` and copies the guide to `GUIDE_SHARE`.

"the guide matches rules page version N" means there was nothing to update. Each run is safe to repeat. If it starts without a terminal, for example from an agent, it uses the saved page and doesn't publish.

| It stops with | What to do |
| --- | --- |
| `Confluence refused the token` | Create a new personal access token, then run it again. |
| `couldn't reach Confluence` | Check the network, or press Enter at the token prompt to use the saved page. |
| `unknown topic …` or `unknown result …` | SEG added a topic or a kind of result. That's a code change on this laptop: add the topic to `CLUSTER_OF` in `check_guide.py`, with a data cluster (`key`, `name`, `hint`) and an icon in `CLUSTER_ICON`; or add the result to `RESULT_OF` with the verdict it means. A topic with several data clusters also needs its default in `DEFAULT_CLUSTER` in `update_guide.py`. |
| `FAIL … review wording or legal citation …`, `FAIL … external URL …` | The page's own text for a new or reworded row can't go into the guide as it is. Add or edit that data point by hand (see "Updating the guide") with your own wording, then run the update again. |
| `FAIL Nr N condition: needs German and English text` | A "Mit Bedingungen" row has an empty condition cell. Ask SEG to fill it in, or add the data point by hand. |
| `… isn't in the data block's usual format` | A hand edit changed a data point's layout. Lay it out like its neighbours: one line with `row`, `cluster`, `verdict` and `src`, then `name`, `condition` and `keywords`. |

**Page wording.** New and reworded rules go in straight away with the page's own name and condition, marked `"pageWording": true`, so nothing waits for wording. The run lists them and writes `source/wording-request.md`, with the page's text, the style rules and the answer format. Any agent, or a person, can write the answer as `source/wording.json`. The next run applies it, removes the mark, and renames the file to `wording-applied-….json`. Polishing by hand works too: edit the data point and delete `"pageWording": true`.

**Wording:** names and conditions are written for employees, in German and English, using "du". They are never copied from the page; page wording is the stopgap until they're polished. Version 2 was released without the AI Crew's sign-off; agree with SEG whether later wording changes need it.

**Keeping the two laptops in step.** There's no Git on the company laptop. Data updates happen only there: after a publish, copy the guide back here and commit it as "Data update: rules page version N". Code changes happen only here: first bring the latest guide back, then send `check_guide.py`, `update_guide.py` and `README.md` there as a zip, plus the guide if the change touched it. Changes that don't come from the rules page, such as links, labels or wording, are made here by hand (see "Updating the guide"), checked, and sent across the same way.

## Updating the guide

Everything that changes lives in the JSON block between the `GUIDE DATA` markers near the end of the file. Edit it in a text editor, then run the check.

- **Change a verdict or condition**: find the data point by its `row`, which is its Nr on the rules page. `verdict` is one of `not_permitted`, `to_be_clarified`, `internal_ai_only`, `permitted_with_conditions`, `permitted`. Only `permitted_with_conditions` carries a `condition`. Every text has a `de` and an `en` version. The verdict must match the rules page, and the check fails otherwise. The page's "Nur anonymisiert" counts as `permitted_with_conditions` and "Rechtsprüfung offen" as `not_permitted`. A "Klärung nötig" row is `to_be_clarified`: it's listed in question 2 and always leads to Clarify first (ADR 0005).
- **Wording and `src`**: the guide's names and conditions are written for employees, never copied from the page. `src` records which version of the page's English text, condition and result the wording was checked against. When SEG rewords or renumbers a row or changes its result, the check prints the new text and the new `src`. Check the wording, then paste the `src`.
- **Publish a data point the rules page added**: add it to `dataPoints` with `row` set to its Nr (copy an existing entry), write its texts and keywords, run the check and paste the `src` it prints. A new topic on the page needs an entry in `CLUSTER_OF` in `check_guide.py`.
- **Links**: `links.axSupport` (the AX Support portal), `links.internalAi` (Knox Copilot / Samsung Gauss) and `links.aiPolicy` (the rules page) hold `https://` addresses, set on 29 Oct 2026. They open in a new tab, so the data check keeps its answers. `PENDING` shows "link pending" instead. `links.logo` takes an inline `data:image/…` URI, never an external image.
- **The rules page is the reference.** The guide is only the data check. On the result, each data point under "Rules for this data" links to the rules page (`links.aiPolicy`), and "Preparing your data" (`ui.prepareHeading`, `ui.prepare`) links to the Data Preparation Guide (`links.prepGuide`), the PDF on the rules page. It shows only on a "Permitted with conditions" result where a condition to follow asks to anonymise. The "only anonymised" conditions write `{link}` where that link goes, in both languages. `links.prepGuide` points to the rules page; to open the PDF itself, set it to the PDF's address on Confluence.
- **Data check wording**: `outcomes` holds the five results of the data check (`heading`, `reason` = the one sentence under the heading, `whatToDo`); the questions and buttons are in `ui`. The title in the header goes back to the start screen. Two switches in the header: light/dark (`ui.darkMode`), which starts like the device, and DE/EN, which starts in German. The browser remembers both choices. Print is always light.
- **Data cluster tiles**: each data cluster has a `name` and a `hint`, the short example line on its tile in question 1 (e.g. "Modelle, Specs, Bilder, Seriennummern"). The order of `clusters` is the order of the tiles and of the groups in question 2. Never change a data point's `cluster` key to rename a data cluster; edit its `name`.
- **Verdict tags**: each verdict has a `label` (shown under "Rules for this data" on the result) and a `short` word for the coloured tags under "Your choices" (Nein, Ungeklärt, Nur intern, Mit Bedingung, Erlaubt). Question 2 shows no verdicts.
- **Version and date**: `meta.version` and `meta.asOf` (YYYY-MM-DD).

## Archive

`archive/` holds the two POCs that were presented to management: the SEG yes/no POC (`seg-ai-data-check-poc.html`) and the public-guidance POC (`ai-data-check-poc.html`), with their old scenario scripts. They have been frozen since 29 Oct 2026. Nothing checks them, and they aren't kept in step with the guide. All changes go to `seg-ai-data-guide.html`.

## Checking

```sh
python -I check_guide.py             # checks the guide; must end with "ok"; compares it with the rules page when source/confluence.json is there
python -I check_guide.py --selftest  # after changing check_guide.py itself
python -I update_guide.py --selftest # after changing update_guide.py or check_guide.py
```

When SEG changes the rules page, the check fails against the saved page and lists what to update. Without `source/confluence.json`, it checks the guide on its own.

After changing the guide's behaviour, run `checks/data-check-scenarios.js` with the Playwright MCP tool `browser_run_code_unsafe` (parameter `filename`). It walks the data check through every outcome in a real browser and must return `"ok": true`.

`source/` holds the client's files, including the saved rules page, and is never committed.

## Background

- `CONTEXT.md`: the terms used here (data point, verdict, condition…)
- `docs/adr/`: why the guide is one self-contained file, why employees never see review comments, why the Confluence rules page is the source (ADR 0003), why the update script writes the guide's data from it (ADR 0004), and why undecided rows are listed (ADR 0005)
- `.scratch/confluence-source/spec.md`: how the check reads the rules page
- `.scratch/rules-page-sync/spec.md`: how `update_guide.py` updates and publishes the guide (ADR 0004)
- `.scratch/seg-ai-data-guide/spec.md`: what v1 contains and why
- `.scratch/seg-ai-data-check-poc/spec.md`: the archived SEG POC's decisions and its question set
